# =============================================================================
# agents/planner.py — Planner Agent
# =============================================================================
# PATH FIX
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
# =============================================================================
#
# WHAT THIS AGENT DOES:
#   Receives the user's raw query and produces a structured plan:
#     1. Breaks complex questions into focused sub-questions
#     2. Writes a search strategy for the Retriever Agent
#
# WHY DO WE NEED A PLANNER?
#   Without planning, the Retriever would search for the full raw question.
#   For complex queries like "What is the leave policy and IT security rules?",
#   a single search might miss half the answer.
#   The Planner ensures every sub-topic gets its own focused retrieval.
#
# WHERE IT FITS:
#   It is the FIRST node in the LangGraph pipeline.
#   Input:  state["query"]
#   Output: state["sub_questions"], state["search_strategy"],
#           state["execution_trace"]
# =============================================================================

import os
import ssl

os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["REQUESTS_CA_BUNDLE"] = ""
os.environ["CURL_CA_BUNDLE"] = ""
ssl._create_default_https_context = ssl._create_unverified_context

import json
from agents.state import AgentState
from utils.logger import AgentLogger

# Patch httpx for corporate proxy
try:
    import httpx
    _orig = httpx.Client.__init__
    def _patched(self, *args, **kwargs):
        kwargs.setdefault("verify", False)
        _orig(self, *args, **kwargs)
    httpx.Client.__init__ = _patched
except ImportError:
    pass


# =============================================================================
# Planner Prompt
# =============================================================================
# This is the instruction we give to the LLM.
# Notice we ask it to reply in JSON — this makes parsing the response easy
# and reliable. We will extract sub_questions and search_strategy from it.

PLANNER_PROMPT = """You are a query planning assistant for an enterprise knowledge system.

Your job is to analyse the user's question and break it into a structured search plan.

User Question: {query}

Instructions:
1. If the question is simple (one topic), keep it as one sub-question.
2. If the question is complex (multiple topics), break it into 2-4 focused sub-questions.
3. Write a brief search strategy describing what to look for.

Reply ONLY with a valid JSON object in exactly this format (no other text):
{{
  "sub_questions": ["sub-question 1", "sub-question 2"],
  "search_strategy": "brief description of what to search for"
}}"""


# =============================================================================
# Planner Node Function
# =============================================================================

def planner_node(state: AgentState) -> dict:
    """
    LangGraph node — the Planner Agent.

    This function is registered as a node in the LangGraph workflow.
    LangGraph calls it automatically, passing the current state.
    It must return a dict of state fields to update.

    Args:
        state: The current AgentState (read-only input)

    Returns:
        dict with updated state fields:
          - sub_questions
          - search_strategy
          - execution_trace (appended)
          - error (only if something goes wrong)
    """
    agent_log = AgentLogger("PlannerAgent")
    agent_log.start(f"Planning for query: '{state['query']}'")

    try:
        # ------------------------------------------------------------------
        # Step 1: Get the LLM
        # ------------------------------------------------------------------
        from config import get_llm
        llm = get_llm()

        # ------------------------------------------------------------------
        # Step 2: Build the prompt with the user's query
        # ------------------------------------------------------------------
        prompt = PLANNER_PROMPT.format(query=state["query"])
        agent_log.step("Sending query to LLM for planning...")

        # ------------------------------------------------------------------
        # Step 3: Call the LLM
        # LangChain's .invoke() sends the prompt and returns a response object
        # response.content contains the text reply
        # ------------------------------------------------------------------
        response = llm.invoke(prompt)
        raw_response = response.content.strip()
        agent_log.step(f"LLM response received: {raw_response[:100]}...")

        # ------------------------------------------------------------------
        # Step 4: Parse the JSON response
        # We asked the LLM to reply in JSON — now we extract the fields.
        # We use a try/except in case the LLM adds extra text around the JSON.
        # ------------------------------------------------------------------
        # Clean up common LLM formatting issues
        # (sometimes LLMs wrap JSON in ```json ... ``` code blocks)
        if "```" in raw_response:
            raw_response = raw_response.split("```")[1]
            if raw_response.startswith("json"):
                raw_response = raw_response[4:]

        plan = json.loads(raw_response)

        sub_questions = plan.get("sub_questions", [state["query"]])
        search_strategy = plan.get("search_strategy", "Search for relevant information")

        # ------------------------------------------------------------------
        # Step 5: Validate the output
        # Always ensure we have at least one sub-question
        # ------------------------------------------------------------------
        if not sub_questions:
            sub_questions = [state["query"]]

        agent_log.step(f"Identified {len(sub_questions)} sub-question(s):")
        for i, sq in enumerate(sub_questions):
            agent_log.step(f"  {i+1}. {sq}")
        agent_log.step(f"Search strategy: {search_strategy}")
        agent_log.done("Planning complete")

        # ------------------------------------------------------------------
        # Return the updated state fields
        # LangGraph merges this dict into the existing state
        # ------------------------------------------------------------------
        return {
            "sub_questions": sub_questions,
            "search_strategy": search_strategy,
            "execution_trace": [
                f"Planner: identified {len(sub_questions)} sub-question(s) — "
                f"{'; '.join(sub_questions)}"
            ],
        }

    except json.JSONDecodeError as e:
        # LLM didn't return valid JSON — fall back to using the raw query
        agent_log.warning(
            f"Could not parse LLM JSON response: {e}. "
            "Using original query as single sub-question."
        )
        return {
            "sub_questions": [state["query"]],
            "search_strategy": "Search for information related to the query",
            "execution_trace": [
                "Planner: JSON parse failed — using original query directly"
            ],
        }

    except Exception as e:
        agent_log.error(f"Planner failed: {e}")
        return {
            "sub_questions": [state["query"]],
            "search_strategy": "Direct search",
            "error": f"Planner error: {str(e)}",
            "execution_trace": [f"Planner: error occurred — {str(e)}"],
        }


# =============================================================================
# Self-test — run: python agents/planner.py
# =============================================================================

if __name__ == "__main__":
    from agents.state import create_initial_state

    print("=" * 60)
    print("Planner Agent — Self Test")
    print("=" * 60)

    # Test 1: Simple question
    print("\nTest 1: Simple question")
    print("-" * 40)
    state = create_initial_state("What is the annual leave policy?")
    result = planner_node(state)
    print(f"Sub-questions  : {result['sub_questions']}")
    print(f"Strategy       : {result['search_strategy']}")
    print(f"Trace          : {result['execution_trace']}")

    # Test 2: Complex multi-topic question
    print("\nTest 2: Complex question")
    print("-" * 40)
    state2 = create_initial_state(
        "What is the work from home policy and what are the password requirements?"
    )
    result2 = planner_node(state2)
    print(f"Sub-questions  : {result2['sub_questions']}")
    print(f"Strategy       : {result2['search_strategy']}")
    print(f"Trace          : {result2['execution_trace']}")

    print("\n✅ Planner Agent working correctly!")