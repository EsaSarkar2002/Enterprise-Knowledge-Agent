# =============================================================================
# agents/reasoning.py — Reasoning Agent
# =============================================================================
# PATH FIX
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
# =============================================================================
#
# WHAT THIS AGENT DOES:
#   Takes the retrieved document chunks and generates a grounded answer
#   to the user's question using the LLM.
#
# WHY "GROUNDED"?
#   We explicitly tell the LLM: "Answer ONLY using the context provided.
#   Do NOT use your general knowledge."
#   This prevents hallucination — the AI can only say what the documents say.
#
# WHERE IT FITS:
#   Input : state["query"], state["retrieved_docs"]
#   Output: state["answer"], state["sources_used"],
#           state["execution_trace"]
# =============================================================================

import os
import ssl

os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["REQUESTS_CA_BUNDLE"] = ""
os.environ["CURL_CA_BUNDLE"] = ""
ssl._create_default_https_context = ssl._create_unverified_context

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from typing import List
from langchain_core.documents import Document
from agents.state import AgentState
from utils.logger import AgentLogger


# =============================================================================
# Reasoning Prompt
# =============================================================================
# This prompt is the core guardrail against hallucination.
# Key elements:
#   1. "ONLY use the context" — prevents using general knowledge
#   2. "If not in context, say so" — prevents making things up
#   3. "Cite the source" — adds transparency
#   4. Structured output — makes parsing easier

REASONING_PROMPT = """You are an enterprise knowledge assistant. Your job is to answer questions based ONLY on the provided document context.

STRICT RULES:
1. Answer ONLY using information from the context below.
2. Do NOT use your general knowledge or make assumptions.
3. If the answer is not in the context, say exactly: "I could not find this information in the available documents."
4. Always mention which section or document your answer comes from.
5. Be precise and factual — this is an enterprise system.

CONTEXT FROM DOCUMENTS:
{context}

USER QUESTION: {query}

Provide a clear, well-structured answer based strictly on the context above:"""


def _format_context(docs: List[Document]) -> str:
    """
    Format retrieved documents into a readable context block for the LLM.

    Each chunk is labeled with its source and chunk number so the LLM
    can cite where information comes from.

    Example output:
      [Source: sample_policy.txt | Chunk 1]
      Employees are entitled to 18 days of annual leave...

      [Source: sample_policy.txt | Chunk 2]
      Sick leave is 12 days per year...

    Args:
        docs: List of Document objects from the Retriever

    Returns:
        Formatted string ready to insert into the prompt
    """
    if not docs:
        return "No documents retrieved."

    formatted_chunks = []
    for doc in docs:
        source = doc.metadata.get("source", "unknown")
        chunk_idx = doc.metadata.get("chunk_index", "?")
        chunk_text = doc.page_content.strip()

        formatted_chunks.append(
            f"[Source: {source} | Chunk {chunk_idx}]\n{chunk_text}"
        )

    return "\n\n---\n\n".join(formatted_chunks)


# =============================================================================
# Reasoning Node Function
# =============================================================================

def reasoning_node(state: AgentState) -> dict:
    """
    LangGraph node — the Reasoning Agent.

    Generates a grounded answer from retrieved documents.

    Args:
        state: Current AgentState with retrieved_docs and query

    Returns:
        dict with:
          - answer       : The generated answer string
          - sources_used : List of source document names
          - execution_trace: Step added to trace
          - error        : Set only if reasoning fails
    """
    agent_log = AgentLogger("ReasoningAgent")
    agent_log.start(f"Generating answer for: '{state['query']}'")

    try:
        # ------------------------------------------------------------------
        # Step 1: Check we have documents to reason over
        # ------------------------------------------------------------------
        retrieved_docs = state.get("retrieved_docs", [])

        if not retrieved_docs:
            agent_log.warning(
                "No retrieved documents — cannot generate grounded answer."
            )
            return {
                "answer": (
                    "I could not find this information in the available documents. "
                    "No relevant content was retrieved from the knowledge base."
                ),
                "sources_used": [],
                "execution_trace": [
                    "Reasoning: no documents available — returned default response"
                ],
            }

        agent_log.step(f"Reasoning over {len(retrieved_docs)} retrieved chunks")

        # ------------------------------------------------------------------
        # Step 2: Format the retrieved chunks into a context string
        # ------------------------------------------------------------------
        context = _format_context(retrieved_docs)
        agent_log.step(
            f"Context prepared: {len(context)} characters from "
            f"{len(retrieved_docs)} chunks"
        )

        # ------------------------------------------------------------------
        # Step 3: Build the full prompt
        # ------------------------------------------------------------------
        prompt = REASONING_PROMPT.format(
            context=context,
            query=state["query"],
        )

        # ------------------------------------------------------------------
        # Step 4: Call the LLM to generate the answer
        # ------------------------------------------------------------------
        from config import get_llm
        llm = get_llm()

        agent_log.step("Sending context + question to LLM...")
        response = llm.invoke(prompt)
        answer = response.content.strip()

        agent_log.step(f"Answer received ({len(answer)} characters)")

        # ------------------------------------------------------------------
        # Step 5: Extract unique sources used
        # ------------------------------------------------------------------
        sources_used = list(set(
            doc.metadata.get("source", "unknown")
            for doc in retrieved_docs
        ))

        # ------------------------------------------------------------------
        # Step 6: Check if the LLM admitted it couldn't find the answer
        # This is actually GOOD — it means the guardrails are working
        # ------------------------------------------------------------------
        not_found_phrase = "could not find this information"
        if not_found_phrase in answer.lower():
            agent_log.warning(
                "LLM indicated the answer was not in the documents. "
                "Guardrails working correctly."
            )

        agent_log.done(
            f"Answer generated from {len(sources_used)} source(s): "
            f"{sources_used}"
        )

        return {
            "answer": answer,
            "sources_used": sources_used,
            "execution_trace": [
                f"Reasoning: generated {len(answer)}-character answer "
                f"from {len(retrieved_docs)} chunks "
                f"across {len(sources_used)} source(s)"
            ],
        }

    except Exception as e:
        agent_log.error(f"Reasoning failed: {e}")
        return {
            "answer": "An error occurred while generating the answer.",
            "sources_used": [],
            "error": f"Reasoning error: {str(e)}",
            "execution_trace": [f"Reasoning: error — {str(e)}"],
        }


# =============================================================================
# Self-test — run: python agents/reasoning.py
# =============================================================================

if __name__ == "__main__":
    from agents.state import create_initial_state
    from agents.planner import planner_node
    from agents.retriever import retriever_node

    print("=" * 60)
    print("Reasoning Agent — Self Test")
    print("=" * 60)
    print("(This test runs the full Planner → Retriever → Reasoning chain)")

    # Test 1: Simple query
    print("\nTest 1: Simple query")
    print("-" * 40)
    state = create_initial_state("What is the annual leave policy?")

    # Run Planner
    print("Running Planner...")
    plan = planner_node(state)
    state.update(plan)

    # Run Retriever
    print("Running Retriever...")
    retrieval = retriever_node(state)
    state.update(retrieval)

    # Run Reasoning
    print("Running Reasoning...")
    reasoning = reasoning_node(state)
    state.update(reasoning)

    print(f"\n{'='*60}")
    print("FINAL ANSWER:")
    print(f"{'='*60}")
    print(state["answer"])
    print(f"\nSources used: {state['sources_used']}")
    print(f"\nExecution trace:")
    for step in state["execution_trace"]:
        print(f"  → {step}")

    # Test 2: Question outside the knowledge base (guardrail test)
    print(f"\n{'='*60}")
    print("Test 2: Question outside knowledge base (guardrail test)")
    print("-" * 40)
    state2 = create_initial_state("What is the company's stock price?")

    plan2 = planner_node(state2)
    state2.update(plan2)

    retrieval2 = retriever_node(state2)
    state2.update(retrieval2)

    reasoning2 = reasoning_node(state2)
    state2.update(reasoning2)

    print(f"\nANSWER (should say 'not found'):")
    print(state2["answer"])

    print("\n✅ Reasoning Agent working correctly!")