# =============================================================================
# agents/evaluator.py — Evaluator Agent
# =============================================================================
# PATH FIX
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
# =============================================================================
#
# WHAT THIS AGENT DOES:
#   The final agent in the pipeline. Produces a confidence score and
#   a structured evaluation report for every query-answer pair.
#
# WHY DO WE NEED AN EVALUATOR?
#   Enterprise AI systems need to be auditable. Decision-makers need to know:
#   - How confident should I be in this answer?
#   - Where did the information come from?
#   - What steps did the system take?
#   - Were there any quality issues?
#
# CONFIDENCE SCORE FORMULA:
#   confidence = weighted average of:
#     - retrieval_score  (40%) : How relevant were the retrieved chunks?
#     - validity_score   (40%) : Did the validator approve the answer?
#     - length_score     (20%) : Is the answer a reasonable length?
#
# WHERE IT FITS:
#   Input : entire state (reads everything)
#   Output: state["confidence"], state["execution_trace"]
#           + prints final formatted report
# =============================================================================

import os
import ssl
from datetime import datetime

os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["REQUESTS_CA_BUNDLE"] = ""
os.environ["CURL_CA_BUNDLE"] = ""
ssl._create_default_https_context = ssl._create_unverified_context

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from agents.state import AgentState
from utils.logger import AgentLogger


# =============================================================================
# Evaluator Node Function
# =============================================================================

def evaluator_node(state: AgentState) -> dict:
    """
    LangGraph node — the Evaluator Agent.

    Computes a confidence score and formats the final evaluation report.
    Does NOT call the LLM — pure computation, fast and free.

    Args:
        state: Complete AgentState after all other agents have run

    Returns:
        dict with:
          - confidence    : Float 0.0–1.0 overall confidence score
          - execution_trace: Final step added to trace
    """
    agent_log = AgentLogger("EvaluatorAgent")
    agent_log.start("Evaluating pipeline output")

    # ------------------------------------------------------------------
    # Collect all values needed for scoring
    # ------------------------------------------------------------------
    answer = state.get("answer", "")
    retrieved_docs = state.get("retrieved_docs", [])
    retrieval_score = state.get("retrieval_score") or 0.0
    is_valid = state.get("is_valid")
    validation_message = state.get("validation_message", "")
    sub_questions = state.get("sub_questions") or [state["query"]]
    sources_used = state.get("sources_used") or []
    execution_trace = state.get("execution_trace") or []
    error = state.get("error")

    # ------------------------------------------------------------------
    # Score Component 1: Retrieval Quality (40% weight)
    # Already calculated by Retriever as 0.0–1.0
    # ------------------------------------------------------------------
    retrieval_component = retrieval_score
    agent_log.step(f"Retrieval component : {retrieval_component:.3f} (weight 40%)")

    # ------------------------------------------------------------------
    # Score Component 2: Validity Score (40% weight)
    # 1.0 if validator approved, 0.3 if rejected (not 0 — partial credit
    # because the pipeline still ran and produced something)
    # ------------------------------------------------------------------
    if is_valid is True:
        validity_component = 1.0
    elif is_valid is False:
        validity_component = 0.3
    else:
        # Validator didn't run — neutral score
        validity_component = 0.5

    agent_log.step(f"Validity component  : {validity_component:.3f} (weight 40%)")

    # ------------------------------------------------------------------
    # Score Component 3: Answer Length Score (20% weight)
    # We expect a good answer to be 50–500 characters.
    # Too short (< 50) or error message → low score
    # Good length (50–500) → high score
    # Very long (> 500) → slight penalty (might be verbose/off-topic)
    # ------------------------------------------------------------------
    answer_len = len(answer.strip()) if answer else 0

    if answer_len < 20:
        length_component = 0.0       # Empty or too short
    elif answer_len < 50:
        length_component = 0.4       # Very short
    elif answer_len <= 500:
        length_component = 1.0       # Good length
    elif answer_len <= 1000:
        length_component = 0.8       # Acceptable but long
    else:
        length_component = 0.6       # Too verbose

    agent_log.step(
        f"Length component    : {length_component:.3f} "
        f"(answer: {answer_len} chars, weight 20%)"
    )

    # ------------------------------------------------------------------
    # Final Confidence Score (weighted average)
    # ------------------------------------------------------------------
    confidence = round(
        (retrieval_component * 0.40) +
        (validity_component  * 0.40) +
        (length_component    * 0.20),
        3
    )

    agent_log.step(f"Final confidence    : {confidence:.3f}")

    # ------------------------------------------------------------------
    # Confidence interpretation
    # ------------------------------------------------------------------
    if confidence >= 0.80:
        confidence_label = "HIGH ✅"
    elif confidence >= 0.60:
        confidence_label = "MEDIUM ⚠️"
    else:
        confidence_label = "LOW ❌"

    agent_log.done(
        f"Evaluation complete — "
        f"Confidence: {confidence} ({confidence_label})"
    )

    # ------------------------------------------------------------------
    # Build the final structured report
    # This is what gets printed at the end of the pipeline
    # ------------------------------------------------------------------
    report = _build_report(
        query=state["query"],
        answer=answer,
        confidence=confidence,
        confidence_label=confidence_label,
        retrieval_score=retrieval_score,
        is_valid=is_valid,
        validation_message=validation_message,
        sources_used=sources_used,
        retrieved_docs_count=len(retrieved_docs),
        sub_questions=sub_questions,
        execution_trace=execution_trace,
        error=error,
    )

    return {
        "confidence": confidence,
        "execution_trace": [
            f"Evaluator: confidence={confidence} ({confidence_label}) | "
            f"retrieval={retrieval_score:.3f} | "
            f"valid={is_valid}"
        ],
        # Store the formatted report in the state for main.py to display
        "_final_report": report,
    }


def _build_report(
    query, answer, confidence, confidence_label,
    retrieval_score, is_valid, validation_message,
    sources_used, retrieved_docs_count, sub_questions,
    execution_trace, error
) -> str:
    """
    Build a formatted final report string.

    This is the human-readable output that shows the user:
    - The answer
    - Where it came from
    - How confident we are
    - What steps were taken (explainability)
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    separator = "=" * 65

    lines = [
        "",
        separator,
        "  ENTERPRISE KNOWLEDGE AGENT — FINAL REPORT",
        separator,
        f"  Timestamp     : {timestamp}",
        f"  Query         : {query}",
        "",
        "  ANSWER",
        "  " + "-" * 60,
        f"  {answer}",
        "",
        "  EVALUATION METRICS",
        "  " + "-" * 60,
        f"  Confidence Score  : {confidence:.3f} — {confidence_label}",
        f"  Retrieval Quality : {retrieval_score:.3f}",
        f"  Answer Valid      : {is_valid}",
        f"  Chunks Retrieved  : {retrieved_docs_count}",
        f"  Sources Used      : {', '.join(sources_used) if sources_used else 'None'}",
        "",
        "  SUB-QUESTIONS IDENTIFIED",
        "  " + "-" * 60,
    ]

    for i, sq in enumerate(sub_questions):
        lines.append(f"  {i+1}. {sq}")

    lines += [
        "",
        "  EXECUTION TRACE (Explainability)",
        "  " + "-" * 60,
    ]

    for step in execution_trace:
        lines.append(f"  → {step}")

    if validation_message:
        lines += [
            "",
            "  VALIDATION",
            "  " + "-" * 60,
            f"  {validation_message}",
        ]

    if error:
        lines += [
            "",
            "  ERROR DETECTED",
            "  " + "-" * 60,
            f"  {error}",
        ]

    lines += [separator, ""]

    return "\n".join(lines)


# =============================================================================
# Self-test — run: python agents/evaluator.py
# =============================================================================

if __name__ == "__main__":
    from agents.state import create_initial_state
    from agents.planner import planner_node
    from agents.retriever import retriever_node
    from agents.reasoning import reasoning_node
    from agents.validator import validator_node

    print("=" * 65)
    print("Evaluator Agent — Full Pipeline Test")
    print("=" * 65)
    print("Running: Planner → Retriever → Reasoning → Validator → Evaluator")

    # ------------------------------------------------------------------
    # Test 1: Good question — should get HIGH confidence
    # ------------------------------------------------------------------
    print("\nTest 1: Well-answerable question")
    print("-" * 40)
    state = create_initial_state("What is the annual leave policy?")

    state.update(planner_node(state))
    state.update(retriever_node(state))
    state.update(reasoning_node(state))
    state.update(validator_node(state))
    result = evaluator_node(state)
    state.update(result)

    print(state.get("_final_report", "No report generated"))

    # ------------------------------------------------------------------
    # Test 2: Out-of-scope question — should get LOWER confidence
    # ------------------------------------------------------------------
    print("\nTest 2: Out-of-scope question")
    print("-" * 40)
    state2 = create_initial_state("What is the company stock price?")

    state2.update(planner_node(state2))
    state2.update(retriever_node(state2))
    state2.update(reasoning_node(state2))
    state2.update(validator_node(state2))
    result2 = evaluator_node(state2)
    state2.update(result2)

    print(state2.get("_final_report", "No report generated"))

    print("✅ Full pipeline test complete!")