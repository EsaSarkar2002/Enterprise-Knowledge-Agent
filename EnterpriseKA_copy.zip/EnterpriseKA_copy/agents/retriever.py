# =============================================================================
# agents/retriever.py — Retriever Agent
# =============================================================================
# PATH FIX
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
# =============================================================================
#
# WHAT THIS AGENT DOES:
#   Takes the sub-questions from the Planner Agent and searches the
#   vector store for the most relevant document chunks for each one.
#
# WHY ONE SEARCH PER SUB-QUESTION?
#   If the user asked "What is the leave policy and password rules?",
#   the Planner split it into 2 sub-questions.
#   If we searched with just one combined query, FAISS might return
#   chunks about leave but miss the password section entirely.
#   Searching separately for each sub-question guarantees coverage.
#
# WHERE IT FITS:
#   Input : state["sub_questions"], state["search_strategy"]
#   Output: state["retrieved_docs"], state["retrieval_score"],
#           state["execution_trace"]
# =============================================================================

import os
import ssl

os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["REQUESTS_CA_BUNDLE"] = ""
os.environ["CURL_CA_BUNDLE"] = ""
ssl._create_default_https_context = ssl._create_unverified_context

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from typing import List
from langchain_core.documents import Document
from agents.state import AgentState
from utils.logger import AgentLogger


# =============================================================================
# Retriever Node Function
# =============================================================================

def retriever_node(state: AgentState) -> dict:
    """
    LangGraph node — the Retriever Agent.

    Searches the vector store for relevant chunks for each sub-question
    produced by the Planner Agent.

    Args:
        state: Current AgentState containing sub_questions

    Returns:
        dict with:
          - retrieved_docs : List of relevant Document chunks
          - retrieval_score: Average relevance score (0.0 to 1.0)
          - execution_trace: Step added to the trace
          - error          : Set only if retrieval fails completely
    """
    agent_log = AgentLogger("RetrieverAgent")
    agent_log.start("Starting document retrieval")

    try:
        # ------------------------------------------------------------------
        # Step 1: Load the vector store from disk
        # We use get_or_build_vector_store() which:
        #   - Loads from disk if index.faiss exists (fast, no API calls)
        #   - Builds fresh if not found (calls embedding API)
        # ------------------------------------------------------------------
        from retrieval.vector_store import get_or_build_vector_store
        from config import settings

        agent_log.step("Loading vector store from disk...")
        store = get_or_build_vector_store()
        agent_log.step("Vector store ready")

        # ------------------------------------------------------------------
        # Step 2: Get sub-questions from Planner
        # Fall back to original query if Planner didn't run
        # ------------------------------------------------------------------
        sub_questions = state.get("sub_questions") or [state["query"]]
        agent_log.step(
            f"Will search for {len(sub_questions)} sub-question(s): "
            f"{sub_questions}"
        )

        # ------------------------------------------------------------------
        # Step 3: Search for each sub-question separately
        # We collect results with scores to calculate retrieval quality
        # ------------------------------------------------------------------
        all_docs: List[Document] = []
        all_scores: List[float] = []

        # Track seen content to avoid duplicates
        # (same chunk might be returned for multiple sub-questions)
        seen_contents = set()

        for i, question in enumerate(sub_questions):
            agent_log.step(
                f"Searching sub-question {i+1}/{len(sub_questions)}: "
                f"'{question}'"
            )

            # search_with_scores returns (Document, score) tuples
            # Lower score = more similar in FAISS (distance metric)
            results_with_scores = store.search_with_scores(
                query=question,
                top_k=settings.TOP_K_RESULTS,
            )

            for doc, score in results_with_scores:
                # Skip duplicate chunks
                content_key = doc.page_content[:100]
                if content_key in seen_contents:
                    agent_log.step(f"  Skipping duplicate chunk")
                    continue

                seen_contents.add(content_key)
                all_docs.append(doc)
                all_scores.append(float(score))

                agent_log.step(
                    f"  Retrieved [{doc.metadata['source']}] "
                    f"score={score:.4f}: "
                    f"{doc.page_content[:60].replace(chr(10), ' ')}..."
                )

        # ------------------------------------------------------------------
        # Step 4: Calculate retrieval quality score
        #
        # FAISS returns L2 distance scores — lower is better.
        # We convert to a 0-1 quality score using:
        #   quality = 1 / (1 + average_distance)
        #
        # This maps:
        #   distance 0.0 → quality 1.0  (perfect match)
        #   distance 1.0 → quality 0.5  (moderate match)
        #   distance 5.0 → quality 0.17 (poor match)
        # ------------------------------------------------------------------
        if all_scores:
            avg_distance = sum(all_scores) / len(all_scores)
            retrieval_score = round(1.0 / (1.0 + avg_distance), 3)
        else:
            retrieval_score = 0.0

        # ------------------------------------------------------------------
        # Step 5: Handle case where nothing was retrieved
        # ------------------------------------------------------------------
        if not all_docs:
            agent_log.warning(
                "No relevant documents found. "
                "The query may not match any content in the knowledge base."
            )
            return {
                "retrieved_docs": [],
                "retrieval_score": 0.0,
                "execution_trace": [
                    "Retriever: no relevant documents found — "
                    "query may be outside the knowledge base"
                ],
            }

        agent_log.done(
            f"Retrieved {len(all_docs)} unique chunks across "
            f"{len(sub_questions)} sub-question(s). "
            f"Retrieval quality score: {retrieval_score}"
        )

        return {
            "retrieved_docs": all_docs,
            "retrieval_score": retrieval_score,
            "execution_trace": [
                f"Retriever: found {len(all_docs)} relevant chunks "
                f"(quality score: {retrieval_score}) "
                f"from {len(set(d.metadata['source'] for d in all_docs))} "
                f"document(s)"
            ],
        }

    except Exception as e:
        agent_log.error(f"Retrieval failed: {e}")
        return {
            "retrieved_docs": [],
            "retrieval_score": 0.0,
            "error": f"Retriever error: {str(e)}",
            "execution_trace": [f"Retriever: error — {str(e)}"],
        }


# =============================================================================
# Self-test — run: python agents/retriever.py
# =============================================================================

if __name__ == "__main__":
    from agents.state import create_initial_state

    print("=" * 60)
    print("Retriever Agent — Self Test")
    print("=" * 60)

    # Simulate state after Planner has run
    # (In the real pipeline, Planner fills these in automatically)

    # Test 1: Single sub-question
    print("\nTest 1: Single topic query")
    print("-" * 40)
    state = create_initial_state("What is the annual leave policy?")
    state["sub_questions"] = ["What is the annual leave policy?"]
    state["search_strategy"] = "Search for leave policy"

    result = retriever_node(state)
    print(f"Chunks retrieved : {len(result['retrieved_docs'])}")
    print(f"Retrieval score  : {result['retrieval_score']}")
    print(f"Trace            : {result['execution_trace']}")

    if result["retrieved_docs"]:
        print(f"\nTop chunk preview:")
        print(f"  Source : {result['retrieved_docs'][0].metadata['source']}")
        print(f"  Content: {result['retrieved_docs'][0].page_content[:200]}")

    # Test 2: Multiple sub-questions
    print("\nTest 2: Multi-topic query")
    print("-" * 40)
    state2 = create_initial_state(
        "What is the work from home policy and password rules?"
    )
    state2["sub_questions"] = [
        "What is the work from home policy?",
        "What are the password requirements?",
    ]
    state2["search_strategy"] = "Search remote work and IT security"

    result2 = retriever_node(state2)
    print(f"Chunks retrieved : {len(result2['retrieved_docs'])}")
    print(f"Retrieval score  : {result2['retrieval_score']}")

    print(f"\nAll retrieved sources:")
    for doc in result2["retrieved_docs"]:
        print(
            f"  [{doc.metadata['source']}] chunk {doc.metadata['chunk_index']}: "
            f"{doc.page_content[:80].replace(chr(10), ' ')}..."
        )

    print("\n✅ Retriever Agent working correctly!")