# =============================================================================
# agents/validator.py — Validator Agent
# =============================================================================
# PATH FIX
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
# =============================================================================
#
# WHAT THIS AGENT DOES:
#   Acts as a quality gate — checks the Reasoning Agent's answer before
#   it reaches the user. Flags answers that may be hallucinated or incomplete.
#
# WHY DO WE NEED VALIDATION?
#   Even with grounding prompts, LLMs can occasionally:
#   - Add information not in the retrieved chunks
#   - Give vague non-answers when a real answer exists
#   - Fail silently when retrieval quality was poor
#   The Validator catches these cases and flags them explicitly.
#
# VALIDATION CHECKS (in order):
#   1. Error check    — Did a previous agent fail?
#   2. Answer check   — Is there actually an answer?
#   3. Length check   — Is the answer suspiciously short?
#   4. Retrieval check— Was retrieval quality good enough?
#   5. Grounding check— Do key answer terms appear in retrieved docs?
#   6. Refusal check  — Did the AI correctly say "I don't know"?
#
# WHERE IT FITS:
#   Input : state["answer"], state["retrieved_docs"], state["retrieval_score"]
#   Output: state["is_valid"], state["validation_message"],
#           state["execution_trace"]
# =============================================================================

import os
import ssl

os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["REQUESTS_CA_BUNDLE"] = ""
os.environ["CURL_CA_BUNDLE"] = ""
ssl._create_default_https_context = ssl._create_unverified_context

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from agents.state import AgentState
from utils.logger import AgentLogger


# =============================================================================
# Validator Node Function
# =============================================================================

def validator_node(state: AgentState) -> dict:
    """
    LangGraph node — the Validator Agent.

    Performs rule-based validation of the answer. Does NOT call the LLM —
    this is intentional. Validation should be fast, deterministic, and
    not consume additional API quota.

    Args:
        state: Current AgentState with answer and retrieved_docs

    Returns:
        dict with:
          - is_valid          : True if answer passes all checks
          - validation_message: Human-readable explanation
          - execution_trace   : Step added to trace
    """
    agent_log = AgentLogger("ValidatorAgent")
    agent_log.start("Validating answer quality")

    answer = state.get("answer", "")
    retrieved_docs = state.get("retrieved_docs", [])
    retrieval_score = state.get("retrieval_score", 0.0)
    error = state.get("error", None)

    # ------------------------------------------------------------------
    # Check 1: Did a previous agent encounter an error?
    # ------------------------------------------------------------------
    if error:
        agent_log.warning(f"Pipeline error detected: {error}")
        return _invalid(
            agent_log,
            f"Pipeline error in previous step: {error}",
            "Validator: INVALID — pipeline error detected"
        )

    # ------------------------------------------------------------------
    # Check 2: Is there actually an answer?
    # ------------------------------------------------------------------
    if not answer or answer.strip() == "":
        agent_log.warning("Answer is empty")
        return _invalid(
            agent_log,
            "No answer was generated.",
            "Validator: INVALID — empty answer"
        )

    # ------------------------------------------------------------------
    # Check 3: Is the answer suspiciously short?
    # A real answer should be at least 20 characters.
    # "Yes." or "No." alone is not a useful enterprise answer.
    # ------------------------------------------------------------------
    MIN_ANSWER_LENGTH = 20
    if len(answer.strip()) < MIN_ANSWER_LENGTH:
        agent_log.warning(f"Answer too short: {len(answer)} characters")
        return _invalid(
            agent_log,
            f"Answer is too short ({len(answer)} chars). May be incomplete.",
            "Validator: INVALID — answer too short"
        )

    # ------------------------------------------------------------------
    # Check 4: Was retrieval quality acceptable?
    # If retrieval score is below threshold, the answer may be based
    # on weakly relevant chunks — higher hallucination risk.
    # ------------------------------------------------------------------
    from config import settings
    MIN_RETRIEVAL_SCORE = settings.MIN_CONFIDENCE_THRESHOLD

    if retrieval_score is not None and retrieval_score < MIN_RETRIEVAL_SCORE:
        agent_log.warning(
            f"Low retrieval score: {retrieval_score} "
            f"(threshold: {MIN_RETRIEVAL_SCORE})"
        )
        # This is a WARNING, not a hard failure
        # The answer may still be valid, just less confident
        agent_log.step(
            "Low retrieval quality — answer flagged but not rejected"
        )

    # ------------------------------------------------------------------
    # Check 6: Correct refusal detection
    # If the AI said "I could not find this information", that is
    # actually VALID behavior — the guardrails worked correctly.
    # We mark it valid but note it as a "refusal".
    # ------------------------------------------------------------------
    refusal_phrases = [
        "could not find this information",
        "not available in the documents",
        "not mentioned in the",
        "no information available",
        "cannot find",
    ]

    is_refusal = any(phrase in answer.lower() for phrase in refusal_phrases)

    if is_refusal:
        agent_log.step(
            "Answer is a correct refusal — "
            "AI acknowledged information not in documents"
        )
        return _valid(
            agent_log,
            "Answer correctly states the information is not in the documents. "
            "Guardrails working as expected.",
            "Validator: VALID — correct refusal (guardrails working)",
            retrieval_score,
        )



    # ------------------------------------------------------------------
    # Check 5: Grounding check
    # Do significant words from the answer actually appear in the
    # retrieved documents? This catches obvious hallucinations.
    #
    # Method: Extract meaningful words from the answer (>4 chars),
    # check what percentage appear in the combined retrieved text.
    # Threshold: at least 30% of answer words must appear in docs.
    # ------------------------------------------------------------------
    if retrieved_docs:
        # Combine all retrieved chunk texts into one searchable string
        all_retrieved_text = " ".join(
            doc.page_content.lower() for doc in retrieved_docs
        )

        # Get meaningful words from the answer (skip short stop words)
        answer_words = [
            w.lower().strip(".,!?;:'\"()")
            for w in answer.split()
            if len(w) > 4
        ]

        if answer_words:
            # Count how many answer words appear in the retrieved text
            grounded_words = [
                w for w in answer_words
                if w in all_retrieved_text
            ]
            grounding_ratio = len(grounded_words) / len(answer_words)

            agent_log.step(
                f"Grounding check: {len(grounded_words)}/{len(answer_words)} "
                f"answer words found in retrieved docs "
                f"(ratio: {grounding_ratio:.2f})"
            )

            # If less than 30% of answer words are in retrieved docs,
            # the answer may contain hallucinated content
            if grounding_ratio < 0.30:
                agent_log.warning(
                    f"Low grounding ratio: {grounding_ratio:.2f}. "
                    "Answer may contain information not in documents."
                )
                return _invalid(
                    agent_log,
                    f"Answer appears poorly grounded in retrieved documents "
                    f"(only {grounding_ratio:.0%} of answer terms found in sources).",
                    "Validator: INVALID — low grounding ratio"
                )

    

    # ------------------------------------------------------------------
    # All checks passed — answer is valid
    # ------------------------------------------------------------------
    agent_log.step("All validation checks passed")

    score_note = ""
    if retrieval_score is not None and retrieval_score < MIN_RETRIEVAL_SCORE:
        score_note = f" (Note: retrieval quality was low: {retrieval_score})"

    return _valid(
        agent_log,
        f"Answer is grounded in retrieved documents.{score_note}",
        "Validator: VALID — answer passed all checks",
        retrieval_score,
    )


# =============================================================================
# Helper Functions
# =============================================================================

def _valid(agent_log, message: str, trace: str, retrieval_score=None) -> dict:
    """Return a valid validation result."""
    agent_log.done(f"VALID — {message}")
    return {
        "is_valid": True,
        "validation_message": message,
        "execution_trace": [trace],
    }


def _invalid(agent_log, message: str, trace: str) -> dict:
    """Return an invalid validation result."""
    agent_log.warning(f"INVALID — {message}")
    return {
        "is_valid": False,
        "validation_message": message,
        "execution_trace": [trace],
    }


# =============================================================================
# Self-test — run: python agents/validator.py
# =============================================================================

if __name__ == "__main__":
    from agents.state import create_initial_state
    from agents.planner import planner_node
    from agents.retriever import retriever_node
    from agents.reasoning import reasoning_node
    from langchain_core.documents import Document

    print("=" * 60)
    print("Validator Agent — Self Test")
    print("=" * 60)

    # ------------------------------------------------------------------
    # Test 1: Valid grounded answer
    # ------------------------------------------------------------------
    print("\nTest 1: Valid grounded answer")
    print("-" * 40)
    state = create_initial_state("What is the annual leave policy?")
    state.update(planner_node(state))
    state.update(retriever_node(state))
    state.update(reasoning_node(state))
    result = validator_node(state)
    state.update(result)

    print(f"Is valid         : {state['is_valid']}")
    print(f"Validation msg   : {state['validation_message']}")
    print(f"Answer preview   : {state['answer'][:150] if state['answer'] else 'N/A'}")

    # ------------------------------------------------------------------
    # Test 2: Correct refusal (question outside knowledge base)
    # ------------------------------------------------------------------
    print("\nTest 2: Correct refusal")
    print("-" * 40)
    state2 = create_initial_state("What is the CEO's salary?")
    state2.update(planner_node(state2))
    state2.update(retriever_node(state2))
    state2.update(reasoning_node(state2))
    result2 = validator_node(state2)
    state2.update(result2)

    print(f"Is valid         : {state2['is_valid']}")
    print(f"Validation msg   : {state2['validation_message']}")
    print(f"Answer           : {state2['answer']}")

    # ------------------------------------------------------------------
    # Test 3: Manually inject a bad answer to test rejection
    # ------------------------------------------------------------------
    print("\nTest 3: Hallucinated answer (manually injected)")
    print("-" * 40)
    state3 = create_initial_state("What is the leave policy?")
    state3["retrieved_docs"] = [
        Document(
            page_content="Employees get 18 days annual leave.",
            metadata={"source": "policy.txt", "chunk_index": 0}
        )
    ]
    state3["retrieval_score"] = 0.8
    # Inject a clearly hallucinated answer
    state3["answer"] = (
        "The quantum blockchain algorithm processes 42 teraflops "
        "of neural network data using synergistic paradigms."
    )
    result3 = validator_node(state3)
    print(f"Is valid         : {result3['is_valid']}")
    print(f"Validation msg   : {result3['validation_message']}")

    print("\n✅ Validator Agent self-test complete!")