# =============================================================================
# utils/logger.py — Structured Logging Utility
# =============================================================================
# WHY DO WE NEED THIS?
#
# As our agent pipeline runs, multiple agents execute in sequence.
# We want to see CLEARLY which agent is doing what at each step.
#
# Example output you will see:
#   ▶ START PlannerAgent: Breaking down user query
#     → PlannerAgent: Identified 2 sub-questions
#   ✓ DONE PlannerAgent: Planning complete (0.42s)
#
# WHERE IT FITS:
#   Every agent and module imports this logger for consistent output.
# =============================================================================

import logging
import sys
from datetime import datetime

# Try to import 'rich' for colorful output; fall back to plain if not installed
try:
    from rich.logging import RichHandler
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False


# =============================================================================
# Core Logger Setup
# =============================================================================

def get_logger(name: str) -> logging.Logger:
    """
    Returns a configured logger for the given module name.

    Usage:
        from utils.logger import get_logger
        logger = get_logger(__name__)
        logger.info("Starting retrieval...")

    Args:
        name: Typically __name__ of the calling module

    Returns:
        A configured logging.Logger instance
    """
    logger = logging.getLogger(name)

    # Avoid adding duplicate handlers if logger already exists
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)

    if RICH_AVAILABLE:
        handler = RichHandler(
            rich_tracebacks=True,
            show_time=True,
            show_path=False,
            markup=True,
        )
    else:
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%H:%M:%S",
        )
        handler.setFormatter(formatter)

    logger.addHandler(handler)
    return logger


# =============================================================================
# Agent Step Logger
# =============================================================================

class AgentLogger:
    """
    A higher-level logger for tracing agent execution steps visually.

    Creates clear visual markers so you can follow the flow:
    Planner → Retriever → Reasoning → Validator → Evaluator

    Usage:
        from utils.logger import AgentLogger
        agent_log = AgentLogger("PlannerAgent")
        agent_log.start("Breaking down user query")
        agent_log.step("Identified 2 sub-questions")
        agent_log.done("Planning complete")
    """

    def __init__(self, agent_name: str):
        self.agent_name = agent_name
        self.logger = get_logger(f"agent.{agent_name.lower()}")
        self.start_time = None

    def start(self, message: str):
        """Log the beginning of an agent's work."""
        self.start_time = datetime.now()
        self.logger.info(f"[bold green]▶ START[/bold green] {self.agent_name}: {message}")

    def step(self, message: str):
        """Log an intermediate step within the agent."""
        self.logger.info(f"  [blue]→[/blue] {self.agent_name}: {message}")

    def warning(self, message: str):
        """Log a non-fatal warning."""
        self.logger.warning(f"  [yellow]⚠[/yellow] {self.agent_name}: {message}")

    def error(self, message: str):
        """Log an error."""
        self.logger.error(f"  [red]✗ ERROR[/red] {self.agent_name}: {message}")

    def done(self, message: str):
        """Log successful completion."""
        elapsed = ""
        if self.start_time:
            delta = (datetime.now() - self.start_time).total_seconds()
            elapsed = f" ({delta:.2f}s)"
        self.logger.info(
            f"[bold green]✓ DONE[/bold green] {self.agent_name}: {message}{elapsed}"
        )


# =============================================================================
# Pipeline-level Logging Helpers
# =============================================================================

def log_pipeline_start(query: str):
    """Print a clear banner when the full pipeline starts."""
    logger = get_logger("pipeline")
    logger.info("=" * 60)
    logger.info("[bold]PIPELINE START[/bold]")
    logger.info(f"Query: {query}")
    logger.info("=" * 60)


def log_pipeline_end(success: bool, summary: str = ""):
    """Print a clear banner when the pipeline ends."""
    logger = get_logger("pipeline")
    status = "[bold green]SUCCESS[/bold green]" if success else "[bold red]FAILED[/bold red]"
    logger.info("=" * 60)
    logger.info(f"PIPELINE END — {status}")
    if summary:
        logger.info(f"Summary: {summary}")
    logger.info("=" * 60)


# =============================================================================
# Quick self-test — run: python utils/logger.py
# =============================================================================

if __name__ == "__main__":
    logger = get_logger("test")
    logger.info("This is an INFO message")
    logger.warning("This is a WARNING message")
    logger.error("This is an ERROR message")

    print()

    agent_log = AgentLogger("TestAgent")
    agent_log.start("Processing a test query")
    agent_log.step("Step 1 complete")
    agent_log.step("Step 2 complete")
    agent_log.warning("Found a minor issue")
    agent_log.done("All steps finished")

    print()
    log_pipeline_start("What is the company vacation policy?")
    log_pipeline_end(success=True, summary="Answer generated with 0.85 confidence")