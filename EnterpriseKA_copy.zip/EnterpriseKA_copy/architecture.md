# Architecture — Enterprise Knowledge Agent

This document describes the internal design of the Enterprise Knowledge Agent: its components, the data that flows between them, and the reasoning behind the key design decisions. For setup and usage, see [README.md](README.md).

---

## 1. Overview

The system is a **multi-agent RAG (Retrieval-Augmented Generation) pipeline**. A user's natural-language question is processed by five specialized agents, each responsible for one stage. They communicate through a single shared `AgentState` object that is progressively filled in as it moves down the pipeline.

The two core design principles:

1. **Grounding over generation** — the system must only answer from the supplied documents. Every layer (prompt, validator, confidence score) reinforces this to minimize hallucination.
2. **Explainability** — every answer carries a confidence score, cited sources, and a step-by-step execution trace, so the output is auditable.

---

## 2. High-Level Flow

```
                          ┌────────────────────────────────────────┐
                          │            config.py (settings)          │
                          │   get_llm()  ·  Settings  ·  SSL fixes   │
                          └────────────────────────────────────────┘
                                          ▲   (all agents import)
                                          │
   User ──► main.py ──► graph/workflow.py::run_query(query)
                                          │
                  create_initial_state(query)  ──►  AgentState
                                          │
        ┌─────────────┬─────────────┬─────────────┬──────────────┬─────────────┐
        ▼             ▼             ▼             ▼              ▼             │
   ┌─────────┐  ┌──────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐    │
   │ Planner │─►│Retriever │─►│ Reasoning │─►│ Validator │─►│ Evaluator │────┘
   └─────────┘  └──────────┘  └───────────┘  └───────────┘  └───────────┘
        │             │             │
     LLM call    FAISS search   LLM call
                      │
                      ▼
        retrieval/vector_store.py  ◄── ingestion/document_loader.py
        (FAISS index + Gemini       (PDF/DOCX/TXT → chunks)
         REST embeddings)
```

The orchestrator (`graph/workflow.py`) runs the agents **sequentially**, merging each agent's returned dict into the shared state.

---

## 3. The Shared State (`agents/state.py`)

`AgentState` is a `TypedDict` that acts like a form passed from agent to agent. Each agent reads the fields it needs and writes the fields it owns.

| Field | Written by | Meaning |
|---|---|---|
| `query` | (input) | Original user question — set once, never changed |
| `sub_questions` | Planner | Focused sub-questions derived from the query |
| `search_strategy` | Planner | Note describing what to search for |
| `retrieved_docs` | Retriever | Relevant document chunks (append-merged) |
| `retrieval_score` | Retriever | Retrieval quality, 0.0–1.0 |
| `answer` | Reasoning | The grounded answer text |
| `sources_used` | Reasoning | Source filenames cited |
| `is_valid` | Validator | Did the answer pass quality checks? |
| `validation_message` | Validator | Human-readable validation result |
| `confidence` | Evaluator | Overall confidence, 0.0–1.0 |
| `execution_trace` | all | Running log of each step (append-merged) |
| `error` | any | Set if an agent fails |

**Append vs. replace semantics.** `retrieved_docs` and `execution_trace` are typed `Annotated[List, operator.add]`. The orchestrator honors this: for those keys it *appends* an agent's updates to the existing list; for all other keys it *replaces*. This lets the trace accumulate across the whole run and lets the Retriever contribute chunks across multiple sub-questions.

---

## 4. Components

### 4.1 Orchestrator — `graph/workflow.py`

`run_query(query)` is the heart of the system:

1. Builds the initial state via `create_initial_state`.
2. Defines the ordered pipeline: Planner → Retriever → Reasoning → Validator → Evaluator.
3. **Planner-skip heuristic** (`_needs_planning`): if the query has no multi-part signals (`" and "`, `" also "`, multiple `?`, etc.), the Planner LLM call is skipped entirely — the raw query is used as the single sub-question. This saves one LLM call per simple query, which is significant on a rate-limited free tier.
4. Runs each agent, merging its returned dict into the state (respecting append-vs-replace semantics).
5. **Stale-error clearing:** if an agent returns cleanly (no `error` key), any previous error is cleared. This prevents an early transient failure (e.g. a Planner rate-limit hiccup) from permanently poisoning the Validator even when every later stage succeeded.
6. Each agent is wrapped in try/except — a crash is recorded in `error` and the trace, and the pipeline continues rather than aborting.

> **Note on naming:** despite the `graph/` directory name and "LangGraph" references in comments, the current orchestration is a plain sequential Python loop, not a compiled LangGraph `StateGraph`. The state design (`TypedDict` + `Annotated[..., operator.add]`) is LangGraph-compatible, so migrating to a true graph later would be straightforward.

### 4.2 Planner Agent — `agents/planner.py`

- **Input:** `query` · **Output:** `sub_questions`, `search_strategy`
- Prompts the LLM to return a JSON object splitting complex questions into 2–4 focused sub-questions and a short search strategy.
- Robust parsing: strips ```` ```json ```` code fences, and falls back to using the raw query as a single sub-question on any `JSONDecodeError` or other failure — the pipeline never breaks because the Planner misbehaved.

### 4.3 Retriever Agent — `agents/retriever.py`

- **Input:** `sub_questions` · **Output:** `retrieved_docs`, `retrieval_score`
- Loads the FAISS store via `get_or_build_vector_store()`.
- Runs **one semantic search per sub-question** (rather than one combined search) to guarantee coverage of every sub-topic.
- De-duplicates chunks across sub-questions (keyed on the first 100 chars of content).
- Converts FAISS L2 distance into a 0–1 quality score: `quality = 1 / (1 + avg_distance)`. So distance 0 → 1.0, distance 1 → 0.5, distance 5 → 0.17.

### 4.4 Reasoning Agent — `agents/reasoning.py`

- **Input:** `query`, `retrieved_docs` · **Output:** `answer`, `sources_used`
- The primary anti-hallucination guardrail. Its prompt enforces strict rules: answer **only** from the provided context, never use general knowledge, and if the answer isn't present say exactly *"I could not find this information in the available documents."*
- Formats retrieved chunks into a labelled context block (`[Source: file | Chunk N]`) so the model can attribute its answer.
- If no documents were retrieved, it short-circuits to the standard "not found" response without calling the LLM.

### 4.5 Validator Agent — `agents/validator.py`

- **Input:** `answer`, `retrieved_docs`, `retrieval_score` · **Output:** `is_valid`, `validation_message`
- **Deliberately rule-based — no LLM call.** Validation must be fast, deterministic, and free of additional API quota. Checks, in order:
  1. **Error check** — did a prior agent fail?
  2. **Answer-exists check** — is there a non-empty answer?
  3. **Length check** — at least 20 characters (rejects useless one-word answers).
  4. **Retrieval-quality check** — below threshold is flagged as a warning, not a hard failure.
  5. **Refusal check** — a correct *"could not find this information"* refusal is marked **valid** (the guardrails worked as intended).
  6. **Grounding check** — extracts meaningful answer words (>4 chars) and verifies at least 30% appear in the retrieved text; below that, the answer is rejected as poorly grounded.

### 4.6 Evaluator Agent — `agents/evaluator.py`

- **Input:** entire state · **Output:** `confidence`, formatted final report
- Pure computation, no LLM. Confidence is a weighted average:

  ```
  confidence = 0.40 · retrieval_score
             + 0.40 · validity_score      (1.0 valid · 0.3 invalid · 0.5 if validator didn't run)
             + 0.20 · length_score        (peaks at 50–500 chars)
  ```

- Maps the result to a label: **HIGH** (≥0.80), **MEDIUM** (≥0.60), **LOW** (<0.60).
- Builds a structured, human-readable final report (answer, metrics, sub-questions, execution trace, validation, errors), returned as `_final_report` for `main.py` to display.

---

## 5. Supporting Subsystems

### 5.1 Ingestion — `ingestion/document_loader.py`

- Scans `documents/` for `.pdf`, `.docx`, `.txt` files; dispatches to per-format readers (`pypdf`, `python-docx`, plain text).
- Splits raw text with `RecursiveCharacterTextSplitter` (chunk size 512, overlap 64), preferring paragraph → line → word boundaries to keep sentences intact.
- Emits `Document` objects whose metadata carries `source`, `chunk_index`, `total_chunks`, and `char_count`.

### 5.2 Vector Store — `retrieval/vector_store.py`

- **`GeminiRESTEmbeddings`**: implements LangChain's `Embeddings` interface (`embed_documents`, `embed_query`) but calls the Gemini embedding REST API directly. It paces requests (a 1s pause every 10 chunks) to respect free-tier rate limits.
- **`VectorStore`**: wraps a FAISS index with `build()`, `load()`, `search()`, and `search_with_scores()`.
- **Disk caching:** after the first build, the index is saved (`index.faiss` + `index.pkl`). Subsequent runs load in <1s with zero embedding API calls. `get_or_build_vector_store()` transparently loads-or-builds so agents never worry about it.

### 5.3 Configuration — `config.py`

- `Settings` centralizes all config, loaded from `.env`. One place for keys, model names, paths, and RAG tunables.
- **`get_llm()`** is the single provider-abstraction point. All agents call it; swapping `LLM_PROVIDER` between `gemini` and `claude` in `.env` changes the model everywhere with no code edits.
- **`GeminiRESTLLM`** mimics LangChain's chat interface (`.invoke(prompt).content`) so agents are provider-agnostic. It includes retry-with-backoff and automatic failover to `GOOGLE_API_KEY_BACKUP` on HTTP 429.

### 5.4 Logging — `utils/logger.py`

- `get_logger()` returns a `rich`-enhanced logger (falls back to plain `StreamHandler`).
- `AgentLogger` provides visual `start/step/warning/error/done` markers with timing, so the pipeline flow is easy to follow during development. `main.py` silences these during query execution for a clean user-facing display.

---

## 6. Cross-Cutting Design Decisions

### 6.1 Pure-REST clients (no Google SDK)
The official `langchain_google_genai` / Google SDK depends on `protobuf`, which crashes on Python 3.14 (`Metaclasses with custom tp_new are not supported`). Both the LLM (`GeminiRESTLLM`) and embeddings (`GeminiRESTEmbeddings`) bypass the SDK entirely and use plain `requests` HTTP calls — making the system Python-version-independent while preserving the LangChain interface agents expect.

### 6.2 Corporate-network SSL handling
Every network-touching module sets `PYTHONHTTPSVERIFY=0`, clears CA-bundle env vars, installs an unverified SSL context, and monkey-patches `httpx.Client` to default `verify=False`. This is necessary behind TLS-intercepting corporate proxies. **Security trade-off:** this disables certificate verification globally — acceptable for an internal tool on a trusted network, but it should be revisited (e.g. point to the corporate CA bundle instead) before any untrusted-network deployment.

### 6.3 Quota conservation
Multiple deliberate choices reduce API cost on the free tier: the Planner-skip heuristic, the rule-based (LLM-free) Validator and Evaluator, on-disk caching of the vector index, and paced embedding requests.

### 6.4 Graceful degradation
No single agent failure aborts the run. Each agent catches its own exceptions, records them in `error`/`execution_trace`, and returns safe defaults; the orchestrator continues and the Evaluator still produces a (low-confidence) report.

---

## 7. End-to-End Example

**Query:** *"What is the remote work policy and password requirements?"*

1. **Planner** detects `" and "` → splits into `["What is the remote work policy?", "What are the password requirements?"]`.
2. **Retriever** runs two FAISS searches, collects ~10 unique chunks, computes `retrieval_score ≈ 0.7`.
3. **Reasoning** feeds the labelled chunks + query to the LLM under the strict grounding prompt → produces a cited answer.
4. **Validator** confirms the answer is non-empty, long enough, and ≥30% grounded in the retrieved text → `is_valid = True`.
5. **Evaluator** computes `confidence = 0.4·0.7 + 0.4·1.0 + 0.2·1.0 = 0.88` → **HIGH**, and assembles the final report.

The user sees the answer, the source files, confidence/retrieval/validation metrics, and the full execution trace.

---

## 8. Extension Points

- **New document formats:** add a reader to `ingestion/document_loader.py` and register its extension.
- **New LLM provider:** extend `get_llm()` in `config.py`; agents need no changes.
- **True LangGraph orchestration:** replace the sequential loop in `graph/workflow.py` with a compiled `StateGraph` — the state is already compatible.
- **Smarter retrieval:** add re-ranking, hybrid (keyword + vector) search, or metadata filtering in the Retriever.
- **LLM-based validation:** complement the rule-based Validator with an LLM "judge" for harder grounding cases.
