"""
scripts/check_env.py  --  Milestone 0 sanity check.

Run this to confirm three things work:
  1. Your packages are installed.
  2. config.py loads your .env settings correctly.
  3. Your API key + network can actually reach the LLM.

Run from the project root:
    python scripts/check_env.py
"""

import os
import ssl

# Corporate proxy fix — must be before all other imports
os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["CURL_CA_BUNDLE"] = ""
os.environ["REQUESTS_CA_BUNDLE"] = ""
ssl._create_default_https_context = ssl._create_unverified_context

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from config import settings, get_llm


def mask(secret: str) -> str:
    """Show only the last 4 characters of a secret."""
    if not secret or len(secret) < 4:
        return "(not set)"
    return "****" + secret[-4:]


def main() -> None:
    print("=" * 55)
    print(" Enterprise Knowledge Agent — Environment Check")
    print("=" * 55)

    # --- 1. Show configuration ---
    print(f"LLM provider     : {settings.LLM_PROVIDER}")
    print(f"Gemini model     : {settings.GEMINI_MODEL}")
    print(f"Google API key   : {mask(settings.GOOGLE_API_KEY)}")
    print(f"Embedding model  : {settings.EMBEDDING_MODEL}")
    print(f"Documents dir    : {settings.DOCUMENTS_DIR}")
    print(f"Vector store path: {settings.VECTOR_STORE_PATH}")
    print(f"Log level        : {settings.LOG_LEVEL}")
    print("-" * 55)

    # --- 2. Get the LLM ---
    try:
        llm = get_llm()
        print(f"LLM type         : {type(llm).__name__}")
    except ValueError as err:
        print("[CONFIG ERROR] " + str(err))
        sys.exit(1)

    # --- 3. Test a real API call ---
    print("Sending a test message to the model...")
    try:
        response = llm.invoke(
            "Reply with exactly: Hello, Enterprise Knowledge Agent!"
        )
        # Works for both LangChain models and our GeminiRESTLLM
        content = response.content if hasattr(response, "content") else str(response)
        print("MODEL REPLIED:", content)
        print("-" * 55)
        print("✅ SUCCESS — your environment is ready!")
    except Exception as err:
        print("[CONNECTION ERROR] Could not reach the model.")
        print("Details:", err)
        sys.exit(1)


if __name__ == "__main__":
    main()