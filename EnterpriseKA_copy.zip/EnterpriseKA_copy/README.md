# Enterprise Knowledge Agent

A multi-agent **Retrieval-Augmented Generation (RAG)** system that answers questions about your enterprise documents — and tells you *how confident* it is and *where* the answer came from.

Ask a question in natural language; the system plans the search, retrieves relevant passages from your documents, generates a strictly grounded answer, validates it against the source text, and scores its own confidence. No hallucinated answers — if the information isn't in your documents, it says so.

Powered by a five-agent pipeline running on **LangChain + FAISS + Google Gemini** (with optional Anthropic Claude support).

---

## Key Features

- **Grounded answers only** — the Reasoning Agent is instructed to answer *exclusively* from retrieved document text. Out-of-scope questions get a clear "I could not find this information" rather than a made-up answer.
- **Multi-agent pipeline** — Planner → Retriever → Reasoning → Validator → Evaluator, each with a single responsibility.
- **Self-validation** — a rule-based Validator catches empty, too-short, or poorly-grounded answers before they reach you.
- **Confidence scoring** — every answer comes with a 0.0–1.0 confidence score (HIGH / MEDIUM / LOW) and an explainable execution trace.
- **Semantic search** — FAISS vector index over your documents; finds relevant passages even when the wording differs.
- **Cost-aware** — simple single-topic questions skip the Planner LLM call to conserve API quota; the vector index is built once and cached to disk.
- **Provider-swappable** — switch between Gemini and Claude with a single line in `.env`.
- **Corporate-network friendly** — built-in SSL/proxy workarounds and automatic backup-key failover on rate limits.
- **Pure-REST Gemini client** — bypasses the Google SDK (and its `protobuf` dependency), so it runs on any Python version including 3.14.

---

## Quick Start

### 1. Prerequisites
- Python 3.11+ (works through 3.14)
- A free Google Gemini API key — get one at <https://aistudio.google.com/app/apikey>

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure your environment
Copy the template and add your key:
```bash
cp .env.example .env
```
Then edit `.env`:
```ini
LLM_PROVIDER=gemini
GOOGLE_API_KEY=your_real_key_here
GEMINI_MODEL=gemini-2.0-flash
DOCUMENTS_DIR=documents
VECTOR_STORE_PATH=vector_store
LOG_LEVEL=INFO
```

> ⚠️ **Security note:** Never commit your real `.env`. The committed `.env.example` currently contains a live-looking key — rotate/remove it and treat `.env.example` as a placeholder-only template.

### 4. Verify your setup
```bash
python scripts/check_env.py
```
This confirms your packages, config, and a live API call all work.

### 5. Add your documents
Drop `.pdf`, `.docx`, or `.txt` files into the `documents/` folder. A `sample_policy.txt` is included to get you started.

### 6. Run it
```bash
# Interactive Q&A loop
python main.py

# Or a single question (great for scripting/testing)
python main.py "What is the annual leave policy?"
```

On first run the system indexes your documents into a FAISS vector store (one-time, ~15–30s). Subsequent runs load the cached index instantly.

---

## Usage

In interactive mode:
- Type any question about your documents.
- Type `help` for tips and example questions.
- Type `quit` (or `exit`, `q`, `bye`) to leave.

Example questions for the bundled sample policy:
```
What is the annual leave policy?
How many sick days do employees get?
Can I work from home?
What are the password requirements?
```

Each answer is followed by its **sources**, **confidence/retrieval/validation metrics**, and a step-by-step **execution trace** explaining how the answer was found.

---

## How It Works

A user question flows through five specialized agents, sharing a single `AgentState` object that each agent fills in:

```
Query
  │
  ▼
┌───────────┐   sub-questions, search strategy
│  Planner  │ ─────────────────────────────────►
└───────────┘   (skipped for simple single-topic queries)
  │
  ▼
┌───────────┐   relevant chunks + retrieval score
│ Retriever │ ─── FAISS semantic search ────────►
└───────────┘
  │
  ▼
┌───────────┐   grounded answer + cited sources
│ Reasoning │ ─── LLM, context-only prompt ─────►
└───────────┘
  │
  ▼
┌───────────┐   is_valid? + validation message
│ Validator │ ─── rule-based, no LLM ───────────►
└───────────┘
  │
  ▼
┌───────────┐   confidence score + final report
│ Evaluator │ ─── pure computation, no LLM ─────►
└───────────┘
  │
  ▼
Answer + Sources + Confidence + Trace
```

For a deep dive into each component, the state object, and design decisions, see **[architecture.md](architecture.md)**.

---

## Project Structure

```
EnterpriseKnowledgeAgent/
├── main.py                     # Entry point — interactive & single-query modes
├── config.py                   # Central settings, get_llm(), Gemini REST client
├── requirements.txt
├── .env.example                # Config template (copy to .env)
│
├── agents/                     # The five-agent pipeline
│   ├── state.py                #   Shared AgentState (TypedDict)
│   ├── planner.py              #   1. Breaks query into sub-questions
│   ├── retriever.py            #   2. Semantic search over the vector store
│   ├── reasoning.py            #   3. Generates the grounded answer
│   ├── validator.py            #   4. Rule-based quality gate
│   └── evaluator.py            #   5. Confidence scoring + final report
│
├── graph/
│   └── workflow.py             # Pipeline orchestration (run_query)
│
├── ingestion/
│   └── document_loader.py      # Reads PDF/DOCX/TXT, splits into chunks
│
├── retrieval/
│   └── vector_store.py         # FAISS index + Gemini REST embeddings
│
├── utils/
│   └── logger.py               # Structured / rich logging helpers
│
├── scripts/
│   └── check_env.py            # Environment sanity check
│
├── documents/                  # Your source documents go here
│   └── sample_policy.txt
│
└── vector_store/               # Cached FAISS index (auto-generated)
    ├── index.faiss
    └── index.pkl
```

---

## Configuration Reference

All settings are read from `.env` (see `config.py` → `Settings`):

| Variable | Default | Description |
|---|---|---|
| `LLM_PROVIDER` | `gemini` | `gemini` or `claude` |
| `GOOGLE_API_KEY` | — | Gemini API key (required for Gemini) |
| `GOOGLE_API_KEY_BACKUP` | — | Optional fallback key used on rate-limit |
| `GEMINI_MODEL` | `gemini-2.0-flash` | Gemini model name |
| `ANTHROPIC_API_KEY` | — | Required only if `LLM_PROVIDER=claude` |
| `CLAUDE_MODEL` | `claude-sonnet-4-6` | Claude model name |
| `LLM_TEMPERATURE` | `0.0` | Deterministic answers (best for RAG) |
| `DOCUMENTS_DIR` | `documents` | Folder of source documents |
| `VECTOR_STORE_PATH` | `vector_store` | Where the FAISS index is cached |
| `LOG_LEVEL` | `INFO` | `DEBUG`, `INFO`, or `WARNING` |

Non-env tunables (in `config.py` → `Settings`): `CHUNK_SIZE` (512), `CHUNK_OVERLAP` (64), `TOP_K_RESULTS` (5), `MIN_CONFIDENCE_THRESHOLD` (0.6).

---

## Testing

Most modules are self-testing — run them directly to exercise that component:

```bash
python agents/state.py              # State object walkthrough
python agents/planner.py            # Planner on simple + complex queries
python retrieval/vector_store.py    # Build index + run sample searches
python graph/workflow.py            # Full end-to-end pipeline test
```

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `GOOGLE_API_KEY is not set` | Add your key to `.env` (not `.env.example`). |
| Rate-limit / 429 errors | Free tier is ~60 req/min. Wait 60s, or set `GOOGLE_API_KEY_BACKUP`. |
| `No documents found` | Add PDF/DOCX/TXT files to `documents/` and restart. |
| Answers seem stale after editing docs | Delete `vector_store/` to force a re-index. |
| SSL / proxy errors on a corporate network | Already handled in code (verify disabled); confirm the API host is reachable. |

---

## Tech Stack

- **Orchestration:** LangChain Core, custom sequential pipeline (`graph/workflow.py`)
- **LLM:** Google Gemini (pure-REST client) · optional Anthropic Claude
- **Embeddings:** `gemini-embedding-001` via REST
- **Vector DB:** FAISS (CPU)
- **Document parsing:** `pypdf`, `python-docx`
- **Config/Logging:** `python-dotenv`, `rich`
