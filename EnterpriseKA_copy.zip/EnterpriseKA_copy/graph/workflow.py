# =============================================================================
# graph/workflow.py — Agent Pipeline Orchestration (Pure Python)
# =============================================================================
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import os
import ssl

os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["REQUESTS_CA_BUNDLE"] = ""
os.environ["CURL_CA_BUNDLE"] = ""
ssl._create_default_https_context = ssl._create_unverified_context

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from agents.state import AgentState, create_initial_state
from agents.planner import planner_node
from agents.retriever import retriever_node
from agents.reasoning import reasoning_node
from agents.validator import validator_node
from agents.evaluator import evaluator_node
from utils.logger import get_logger, log_pipeline_start, log_pipeline_end

logger = get_logger(__name__)


# =============================================================================
# Planning Heuristic — Skip Planner LLM call for simple questions
# =============================================================================
# WHY THIS EXISTS:
# Every query currently costs 2 LLM calls minimum (Planner + Reasoning).
# On a rate-limited free tier, that halves how many questions you can ask
# per day. Most real questions are single-topic and don't need to be split
# into sub-questions — only genuinely multi-part questions benefit from
# the Planner. This heuristic detects multi-part questions using simple
# textual signals, and skips the Planner LLM call otherwise.
# =============================================================================

def _needs_planning(query: str) -> bool:
    """
    Decide if a query is complex enough to need the Planner's LLM call.

    Returns True (run Planner) only if the query looks like it bundles
    multiple distinct questions together.
    """
    indicators = [" and ", " also ", " as well as ", " plus "]
    question_marks = query.count("?")
    return question_marks > 1 or any(ind in query.lower() for ind in indicators)


def run_query(query: str) -> dict:
    """
    Run a single query through the agent pipeline.

    Skips the Planner LLM call for simple, single-topic questions to
    conserve API quota — falls back to using the raw query directly.

    Args:
        query: The user's question

    Returns:
        Final state dict with all fields populated by all agents
    """
    log_pipeline_start(query)

    state: AgentState = create_initial_state(query)

    # ------------------------------------------------------------------
    # Build the pipeline — conditionally skip Planner
    # ------------------------------------------------------------------
    pipeline = [
        ("Planner",   planner_node),
        ("Retriever", retriever_node),
        ("Reasoning", reasoning_node),
        ("Validator", validator_node),
        ("Evaluator", evaluator_node),
    ]

    if not _needs_planning(query):
        # Skip Planner entirely — saves one LLM call per simple query
        state["sub_questions"] = [query]
        state["search_strategy"] = "Direct search (simple query — planner skipped)"
        state["execution_trace"] = [
            "Planner: skipped (simple single-topic query, saved 1 API call)"
        ]
        pipeline = pipeline[1:]  # remove Planner, start at Retriever
        logger.info("Skipping Planner — simple query detected")

    # ------------------------------------------------------------------
    # Run each agent in sequence, merging state updates
    # ------------------------------------------------------------------
    for agent_name, agent_fn in pipeline:
        logger.info(f"Running agent: {agent_name}")

        try:
            updates = agent_fn(state)

            for key, value in updates.items():
                if key in ("execution_trace", "retrieved_docs") and isinstance(value, list):
                    existing = state.get(key) or []
                    state[key] = existing + value
                else:
                    state[key] = value

            # ----------------------------------------------------------
            # FIX: Clear stale error if this step ran clean.
            # Without this, an early agent's transient failure (e.g. a
            # Planner rate-limit hiccup) would permanently poison the
            # Validator's check even if every later agent succeeded.
            # ----------------------------------------------------------
            if "error" not in updates:
                state["error"] = None

        except Exception as e:
            logger.error(f"Agent {agent_name} crashed: {e}")
            state["error"] = f"{agent_name} crashed: {str(e)}"
            state["execution_trace"] = (state.get("execution_trace") or []) + [
                f"{agent_name}: CRASHED — {str(e)}"
            ]
            continue

    success = state.get("is_valid", False) or False
    log_pipeline_end(
        success=success,
        summary=f"confidence={state.get('confidence', 'N/A')}"
    )

    return state


# =============================================================================
# Self-test — run: python graph/workflow.py
# =============================================================================

if __name__ == "__main__":
    print("=" * 65)
    print("Agent Pipeline — Workflow Test")
    print("=" * 65)

    test_query = "What is the remote work policy and password requirements?"
    print(f"\nQuery: '{test_query}'")
    print("-" * 65)

    final_state = run_query(test_query)

    print("Answer    :", final_state.get("answer"))
    print("Confidence:", final_state.get("confidence"))
    print("Valid     :", final_state.get("is_valid"))

    print("\n✅ Workflow test complete!")