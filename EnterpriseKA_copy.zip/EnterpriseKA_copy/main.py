# =============================================================================
# main.py — Application Entry Point
# =============================================================================
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

import os
import ssl
import logging

os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["REQUESTS_CA_BUNDLE"] = ""
os.environ["CURL_CA_BUNDLE"] = ""
ssl._create_default_https_context = ssl._create_unverified_context

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from config import validate_config, settings


# =============================================================================
# SILENCE all agent/pipeline logs during query execution
# =============================================================================
# WHY get_logger() HERE INSTEAD OF logging.getLogger()?
# Our utils.logger.get_logger() attaches a handler the FIRST time a logger
# name is used. If we silence with plain logging.getLogger() before that
# first call happens, the agent file later calls get_logger() again,
# which resets the level back to INFO. Using OUR get_logger() here forces
# the handler to attach now, so our CRITICAL level sticks.
# =============================================================================

_LOGGER_NAMES = [
    "agent.planneragent", "agent.retrieveragent",
    "agent.reasoningagent", "agent.validatoragent",
    "agent.evaluatoragent", "agent.vectorstore",
    "pipeline", "retrieval.vector_store",
    "ingestion.document_loader", "graph.workflow",
]


def _silence_logs():
    """Turn off all verbose logging during query execution."""
    from utils.logger import get_logger
    for name in _LOGGER_NAMES:
        logger = get_logger(name)   # ensures handler exists first
        logger.setLevel(logging.CRITICAL)


def _restore_logs():
    """Restore logging after query completes."""
    for name in _LOGGER_NAMES:
        logging.getLogger(name).setLevel(logging.INFO)


# =============================================================================
# Clean Display Functions
# =============================================================================

def print_banner():
    """Print the welcome banner."""
    print()
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║         ENTERPRISE KNOWLEDGE AGENT                          ║")
    print("║         Powered by LangGraph + Gemini                       ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print(f"  Model     : {settings.GEMINI_MODEL}")
    print(f"  Documents : {settings.DOCUMENTS_DIR.name}/")
    print(f"  Type 'quit' to exit | 'help' for tips")
    print("──────────────────────────────────────────────────────────────")
    print()


def print_progress(step: str, current: int, total: int):
    """Show a simple progress indicator."""
    bar_filled = "█" * current
    bar_empty  = "░" * (total - current)
    print(f"\r  [{bar_filled}{bar_empty}] {step}...", end="", flush=True)


def print_final_report(state: dict):
    """
    Print a clean, readable final report.
    Shows only what the user cares about — no internal logs.
    """
    query      = state.get("query", "")
    answer     = state.get("answer", "No answer generated.")
    confidence = state.get("confidence", 0.0) or 0.0
    is_valid   = state.get("is_valid", False)
    sources    = state.get("sources_used") or []
    trace      = state.get("execution_trace") or []
    retrieval  = state.get("retrieval_score", 0.0) or 0.0
    error      = state.get("error")

    if confidence >= 0.80:
        conf_label = "HIGH      ✅"
    elif confidence >= 0.60:
        conf_label = "MEDIUM    ⚠️"
    else:
        conf_label = "LOW       ❌"

    print()
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║                        ANSWER                               ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print()

    answer_lines = answer.strip().split("\n")
    for line in answer_lines:
        while len(line) > 65:
            split_at = line.rfind(" ", 0, 65)
            if split_at == -1:
                split_at = 65
            print(f"  {line[:split_at]}")
            line = line[split_at:].strip()
        if line:
            print(f"  {line}")

    print()
    print("──────────────────────────────────────────────────────────────")
    print("  SOURCES")
    print("──────────────────────────────────────────────────────────────")
    if sources:
        for s in sources:
            print(f"  📄 {s}")
    else:
        print("  No sources cited.")

    print()
    print("──────────────────────────────────────────────────────────────")
    print("  EVALUATION METRICS")
    print("──────────────────────────────────────────────────────────────")
    print(f"  Confidence Score  : {confidence:.3f}  —  {conf_label}")
    print(f"  Retrieval Quality : {retrieval:.3f}")
    print(f"  Answer Validated  : {'Yes ✅' if is_valid else 'No ❌'}")

    print()
    print("──────────────────────────────────────────────────────────────")
    print("  HOW I FOUND THIS  (Execution Trace)")
    print("──────────────────────────────────────────────────────────────")
    for i, step in enumerate(trace, 1):
        display = step if len(step) <= 70 else step[:67] + "..."
        print(f"  {i}. {display}")

    if error:
        print()
        print("──────────────────────────────────────────────────────────────")
        print("  ⚠️  NOTE")
        print("──────────────────────────────────────────────────────────────")
        if "rate limit" in error.lower():
            print("  Gemini API rate limit hit during this query.")
            print("  Please wait 60 seconds before asking another question.")
        else:
            print(f"  {error[:120]}")

    print()
    print("╚══════════════════════════════════════════════════════════════╝")
    print()


def print_help():
    """Show usage tips."""
    print()
    print("  TIPS")
    print("  ────")
    print("  • Ask about topics covered in your documents")
    print("  • Complex questions are broken into sub-questions automatically")
    print("  • If rate limited, wait 60 seconds between questions")
    print("  • Questions outside the documents will be flagged clearly")
    print()
    print("  EXAMPLE QUESTIONS")
    print("  ─────────────────")
    print("  What is the annual leave policy?")
    print("  How many sick days do employees get?")
    print("  Can I work from home?")
    print("  What are the password requirements?")
    print()


# =============================================================================
# Setup Functions
# =============================================================================

def ensure_vector_store():
    """Build vector store if it doesn't exist yet."""
    index_file = settings.VECTOR_STORE_PATH / "index.faiss"

    if not index_file.exists():
        print("  First-time setup: indexing your documents...")
        print("  (This only happens once)\n")

        _silence_logs()
        from ingestion.document_loader import load_documents
        from retrieval.vector_store import VectorStore

        chunks = load_documents(settings.DOCUMENTS_DIR)
        if not chunks:
            print(f"  ERROR: No documents found in documents/ folder.")
            print(f"  Add PDF, DOCX, or TXT files and restart.")
            sys.exit(1)

        store = VectorStore()
        store.build(chunks)
        _restore_logs()

        print(f"  ✅ Indexed {len(chunks)} chunks from your documents.\n")
    else:
        print("  ✅ Knowledge base ready.\n")


# =============================================================================
# Interactive Loop
# =============================================================================

def run_interactive():
    """Clean interactive Q&A loop."""
    from graph.workflow import run_query

    print_banner()
    ensure_vector_store()

    print("  Ready! Ask me anything about your enterprise documents.")
    print()

    while True:
        try:
            query = input("  Your question: ").strip()
            print()

            if not query:
                continue

            if query.lower() in ("quit", "exit", "q", "bye"):
                print("  Goodbye! 👋\n")
                break

            if query.lower() in ("help", "?"):
                print_help()
                continue

            _silence_logs()

            steps = [
                "Planning your question",
                "Searching documents   ",
                "Generating answer     ",
                "Validating answer     ",
                "Evaluating quality    ",
            ]

            print_progress(steps[0], 1, 5)

            import agents.planner   as _p
            import agents.retriever as _r
            import agents.reasoning as _rs
            import agents.validator as _v
            import agents.evaluator as _e

            original_planner   = _p.planner_node
            original_retriever = _r.retriever_node
            original_reasoning = _rs.reasoning_node
            original_validator = _v.validator_node
            original_evaluator = _e.evaluator_node

            def planner_with_progress(state):
                print_progress(steps[0], 1, 5)
                return original_planner(state)

            def retriever_with_progress(state):
                print_progress(steps[1], 2, 5)
                return original_retriever(state)

            def reasoning_with_progress(state):
                print_progress(steps[2], 3, 5)
                return original_reasoning(state)

            def validator_with_progress(state):
                print_progress(steps[3], 4, 5)
                return original_validator(state)

            def evaluator_with_progress(state):
                print_progress(steps[4], 5, 5)
                return original_evaluator(state)

            _p.planner_node    = planner_with_progress
            _r.retriever_node  = retriever_with_progress
            _rs.reasoning_node = reasoning_with_progress
            _v.validator_node  = validator_with_progress
            _e.evaluator_node  = evaluator_with_progress

            final_state = run_query(query)

            _p.planner_node    = original_planner
            _r.retriever_node  = original_retriever
            _rs.reasoning_node = original_reasoning
            _v.validator_node  = original_validator
            _e.evaluator_node  = original_evaluator

            _restore_logs()

            print("\r" + " " * 60 + "\r", end="")

            print_final_report(final_state)

        except KeyboardInterrupt:
            print("\n\n  Interrupted. Goodbye! 👋\n")
            break
        except Exception as e:
            _restore_logs()
            print("\r" + " " * 60 + "\r", end="")
            print(f"\n  ❌ Unexpected error: {e}\n")
            continue


# =============================================================================
# Single Query Mode (command line argument)
# =============================================================================

def run_single_query(query: str):
    """Run one query and exit — for scripting/testing."""
    _silence_logs()

    print(f"\n  Processing: '{query}'")
    print("  Please wait...\n")

    from graph.workflow import run_query
    ensure_vector_store()
    final_state = run_query(query)

    _restore_logs()
    print_final_report(final_state)
    return final_state


# =============================================================================
# Entry Point
# =============================================================================

if __name__ == "__main__":
    if not validate_config():
        print("  ❌ Configuration error — check your .env file.")
        sys.exit(1)

    if len(sys.argv) > 1:
        query = " ".join(sys.argv[1:])
        run_single_query(query)
    else:
        run_interactive()