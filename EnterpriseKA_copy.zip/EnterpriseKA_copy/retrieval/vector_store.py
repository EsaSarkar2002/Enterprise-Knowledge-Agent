# =============================================================================
# retrieval/vector_store.py — Vector Store Builder and Searcher
# =============================================================================
# PATH FIX — allows running this file directly from terminal
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
# =============================================================================

import os
import ssl
import time
from typing import List, Optional

# Corporate network SSL fix
os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["REQUESTS_CA_BUNDLE"] = ""
os.environ["CURL_CA_BUNDLE"] = ""
ssl._create_default_https_context = ssl._create_unverified_context

from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from utils.logger import get_logger, AgentLogger

logger = get_logger(__name__)


# =============================================================================
# Custom Embeddings Class — Pure REST, No Google SDK, No Protobuf
# =============================================================================
# WHY THIS EXISTS:
# The official Google SDK uses 'protobuf' internally which breaks on Python 3.14.
# This class bypasses the SDK completely and calls the Gemini REST API directly
# using the 'requests' library — works on any Python version, any network.
#
# LangChain's Embeddings base class requires TWO methods to be implemented:
#   1. embed_documents(texts) — embeds a list of chunks (used when building index)
#   2. embed_query(text)      — embeds a single query (used when searching)
# Both must be present or Python raises "Can't instantiate abstract class".
# =============================================================================

class GeminiRESTEmbeddings(Embeddings):
    """
    Calls the Gemini embedding REST API directly via HTTP requests.

    Flow:
      text → POST /v1/models/text-embedding-004:embedContent → [0.23, -0.15, ...]
    """

    def __init__(self, api_key: str, model: str = "gemini-embedding-001"):
        self.api_key = api_key
        self.model = model
        # Use v1beta — gemini-embedding-001 lives here (not v1)
        self.url = (
            f"https://generativelanguage.googleapis.com"
            f"/v1beta/models/{self.model}:embedContent"
        )

    def _embed_one(self, text: str) -> List[float]:
        """
        Core method — sends ONE text to Gemini and returns its vector.

        The vector is a list of 768 floats that captures the semantic
        meaning of the text. Similar texts produce similar vectors.
        """
        import requests

        payload = {
            # Model is already in the URL — do NOT repeat it here
            "content": {
                "parts": [{"text": text}]
            }
        }

        response = requests.post(
            self.url,
            params={"key": self.api_key},
            json=payload,
            verify=False,    # Corporate network SSL bypass
            timeout=30,
        )

        if response.status_code != 200:
            raise RuntimeError(
                f"Gemini API error {response.status_code}: "
                f"{response.text[:300]}"
            )

        return response.json()["embedding"]["values"]

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """
        Embed a list of document chunks.

        THIS METHOD IS REQUIRED by LangChain's Embeddings base class.
        FAISS.from_documents() calls this automatically when building the index.

        Args:
            texts: List of chunk strings to embed

        Returns:
            List of vectors — one vector per chunk
        """
        vectors = []
        total = len(texts)

        for i, text in enumerate(texts):
            logger.debug(f"Embedding chunk {i+1}/{total}...")
            vector = self._embed_one(text)
            vectors.append(vector)

            # Avoid hitting Gemini rate limits (free tier = 60 requests/min)
            # Small pause every 10 chunks
            if (i + 1) % 10 == 0:
                time.sleep(1)

        return vectors

    def embed_query(self, text: str) -> List[float]:
        """
        Embed a single query string.

        THIS METHOD IS REQUIRED by LangChain's Embeddings base class.
        FAISS.similarity_search() calls this automatically when searching.

        Args:
            text: The user's question

        Returns:
            A single vector representing the question's meaning
        """
        return self._embed_one(text)


# =============================================================================
# VectorStore Class
# =============================================================================

class VectorStore:
    """
    Manages the FAISS vector index for semantic search over document chunks.

    Two main operations:
      build()  → embed all chunks, store in FAISS, save to disk
      search() → embed query, find closest chunks, return them

    Usage:
        store = VectorStore()
        store.build(chunks)                              # Do once
        results = store.search("leave policy", top_k=3) # Use anytime
    """

    def __init__(self, store_path: Optional[Path] = None):
        from config import settings
        self.store_path = store_path or settings.VECTOR_STORE_PATH
        self._faiss_index = None
        self._embeddings = None
        self.agent_log = AgentLogger("VectorStore")

    def _get_embeddings(self) -> GeminiRESTEmbeddings:
        """
        Return the embedding model (lazy initialization).
        Creates it once and reuses it — avoids redundant setup.
        """
        if self._embeddings is None:
            from config import settings
            self.agent_log.step(
                "Initializing Gemini REST embeddings (no download needed)..."
            )
            self._embeddings = GeminiRESTEmbeddings(
                api_key=settings.GOOGLE_API_KEY
            )
            self.agent_log.step("Embeddings ready")
        return self._embeddings

    def build(self, chunks: List[Document]) -> None:
        """
        Convert all chunks to embeddings and build the FAISS index.

        Steps:
          1. Initialize REST embedder
          2. Send each chunk to Gemini API → receive vectors
          3. Store all vectors in a FAISS index
          4. Save index to disk (so we never re-embed unless documents change)

        Args:
            chunks: List of Document objects from document_loader.py
        """
        if not chunks:
            self.agent_log.warning("No chunks provided — cannot build.")
            return

        self.agent_log.start(f"Building vector index from {len(chunks)} chunks")

        embeddings = self._get_embeddings()

        self.agent_log.step(
            f"Calling Gemini REST API for {len(chunks)} chunks "
            "(~15-30 seconds)..."
        )

        from langchain_community.vectorstores import FAISS

        # FAISS.from_documents() internally calls embed_documents()
        # which sends all chunk texts to Gemini and gets vectors back
        self._faiss_index = FAISS.from_documents(
            documents=chunks,
            embedding=embeddings,
        )

        self.agent_log.step(f"FAISS index built with {len(chunks)} vectors")

        # Save to disk — creates index.faiss and index.pkl
        self.store_path.mkdir(parents=True, exist_ok=True)
        self._faiss_index.save_local(str(self.store_path))

        self.agent_log.done(f"Vector store saved to: {self.store_path}")

    def load(self) -> bool:
        """
        Load a previously saved FAISS index from disk.

        WHY SAVE TO DISK?
        Embedding 15 chunks takes ~15 seconds and costs API calls.
        After the first build(), we save the result. Future runs just
        load from disk in under 1 second — no API calls needed.

        Returns:
            True if loaded successfully, False if no saved index found
        """
        index_file = self.store_path / "index.faiss"

        if not index_file.exists():
            self.agent_log.warning(
                "No saved index found — will build fresh."
            )
            return False

        self.agent_log.start("Loading vector index from disk...")
        embeddings = self._get_embeddings()

        from langchain_community.vectorstores import FAISS

        self._faiss_index = FAISS.load_local(
            folder_path=str(self.store_path),
            embeddings=embeddings,
            allow_dangerous_deserialization=True,
        )

        self.agent_log.done("Vector index loaded from disk")
        return True

    def search(self, query: str, top_k: int = 5) -> List[Document]:
        """
        Find the most relevant document chunks for a given question.

        HOW SEMANTIC SEARCH WORKS:
          1. query text → Gemini API → query vector
          2. FAISS compares query vector against ALL stored chunk vectors
          3. Returns top_k chunks with the smallest vector distance
             (smallest distance = most similar meaning)

        Example:
          Query: "How many sick days do I get?"
          Finds: "Employees are entitled to 12 days of sick leave..."
          (Works even though the exact words don't match!)

        Args:
            query : The user's question
            top_k : How many chunks to return (default 5)

        Returns:
            List of Documents, ordered most relevant → least relevant
        """
        if self._faiss_index is None:
            raise RuntimeError(
                "Vector store not ready. Call build() or load() first."
            )

        self.agent_log.step(f"Searching: '{query}' (top_k={top_k})")
        results = self._faiss_index.similarity_search(query, k=top_k)
        self.agent_log.step(f"Found {len(results)} relevant chunks")

        for i, doc in enumerate(results):
            preview = doc.page_content[:80].replace("\n", " ")
            self.agent_log.step(
                f"  [{i+1}] {doc.metadata['source']}: {preview}..."
            )

        return results

    def search_with_scores(self, query: str, top_k: int = 5):
        """
        Same as search() but also returns similarity scores.

        Lower score = more similar (FAISS uses L2 distance).
        Useful for the Evaluator Agent to measure retrieval quality.

        Returns:
            List of (Document, float) tuples
        """
        if self._faiss_index is None:
            raise RuntimeError(
                "Vector store not ready. Call build() or load() first."
            )
        return self._faiss_index.similarity_search_with_score(query, k=top_k)


# =============================================================================
# Convenience function — used by all agents
# =============================================================================

def get_or_build_vector_store(
    chunks: Optional[List[Document]] = None
) -> VectorStore:
    """
    Smart loader — loads existing index if available, builds fresh if not.

    This is what every agent calls. They don't need to worry about
    whether the index exists or needs building.

    Args:
        chunks: Only needed if no saved index exists yet

    Returns:
        A ready-to-use VectorStore instance
    """
    store = VectorStore()
    loaded = store.load()

    if not loaded:
        if not chunks:
            raise ValueError(
                "No saved vector index found and no chunks provided. "
                "Pass chunks= to build the index."
            )
        store.build(chunks)

    return store


# =============================================================================
# Self-test — run: python retrieval/vector_store.py
# =============================================================================

if __name__ == "__main__":
    from ingestion.document_loader import load_documents
    from config import settings

    print("=" * 60)
    print("Vector Store — Self Test")
    print("=" * 60)

    # Step 1: Load documents
    print("\nStep 1: Loading documents...")
    chunks = load_documents(settings.DOCUMENTS_DIR)
    print(f"Loaded {len(chunks)} chunks")

    # Step 2: Build vector store
    print("\nStep 2: Building vector store with Gemini REST embeddings...")
    store = VectorStore()
    store.build(chunks)

    # Step 3: Test semantic search
    print("\nStep 3: Testing semantic search...")
    test_queries = [
        "How many days of annual leave do employees get?",
        "What is the password policy?",
        "Can I work from home?",
    ]

    for query in test_queries:
        print(f"\n  Query: '{query}'")
        results = store.search(query, top_k=2)
        for i, doc in enumerate(results):
            print(f"  Result {i+1}: [{doc.metadata['source']}]")
            print(f"    {doc.page_content[:150].strip()}")

    print("\n✅ Vector store working correctly!")