# =============================================================================
# ingestion/document_loader.py — Document Ingestion Module
# =============================================================================
# PATH FIX — Allows running this file directly from terminal
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
# =============================================================================

from typing import List
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from utils.logger import get_logger, AgentLogger

logger = get_logger(__name__)


# =============================================================================
# Individual File Readers
# =============================================================================

def _read_txt(file_path: Path) -> str:
    """Read a plain text file."""
    logger.debug(f"Reading TXT: {file_path.name}")
    return file_path.read_text(encoding="utf-8", errors="ignore")


def _read_pdf(file_path: Path) -> str:
    """Read a PDF file page by page and return all text."""
    logger.debug(f"Reading PDF: {file_path.name}")
    try:
        from pypdf import PdfReader
    except ImportError:
        raise ImportError("pypdf not installed. Run: pip install pypdf")

    reader = PdfReader(str(file_path))
    pages_text = []

    for page_num, page in enumerate(reader.pages):
        text = page.extract_text()
        if text and text.strip():
            pages_text.append(text)
            logger.debug(f"  Page {page_num + 1}: {len(text)} characters")

    full_text = "\n\n".join(pages_text)
    logger.debug(f"PDF total: {len(full_text)} characters across {len(pages_text)} pages")
    return full_text


def _read_docx(file_path: Path) -> str:
    """Read a Word document and return all paragraph text."""
    logger.debug(f"Reading DOCX: {file_path.name}")
    try:
        import docx
    except ImportError:
        raise ImportError("python-docx not installed. Run: pip install python-docx")

    doc = docx.Document(str(file_path))
    paragraphs = []

    for para in doc.paragraphs:
        text = para.text.strip()
        if text:
            paragraphs.append(text)

    full_text = "\n\n".join(paragraphs)
    logger.debug(f"DOCX total: {len(full_text)} characters, {len(paragraphs)} paragraphs")
    return full_text


# =============================================================================
# Main Loader Function
# =============================================================================

def load_documents(documents_dir: Path, chunk_size: int = 512, chunk_overlap: int = 64) -> List[Document]:
    """
    Load all supported documents from a directory and split into chunks.

    Args:
        documents_dir : Path to folder containing PDF/DOCX/TXT files
        chunk_size    : Maximum characters per chunk (default: 512)
        chunk_overlap : Characters shared between consecutive chunks (default: 64)

    Returns:
        List[Document] where each Document has:
            .page_content : the chunk text
            .metadata     : source filename, chunk index, etc.
    """
    agent_log = AgentLogger("DocumentLoader")
    agent_log.start(f"Loading documents from: {documents_dir}")

    # ------------------------------------------------------------------
    # Step 1: Find all supported files
    # ------------------------------------------------------------------
    supported_extensions = {".pdf", ".docx", ".txt"}
    files = [
        f for f in documents_dir.iterdir()
        if f.is_file() and f.suffix.lower() in supported_extensions
    ]

    if not files:
        agent_log.warning("No PDF, DOCX, or TXT files found. Add documents first.")
        return []

    agent_log.step(f"Found {len(files)} file(s): {[f.name for f in files]}")

    # ------------------------------------------------------------------
    # Step 2: Read raw text from each file
    # ------------------------------------------------------------------
    readers = {
        ".txt":  _read_txt,
        ".pdf":  _read_pdf,
        ".docx": _read_docx,
    }

    raw_documents = []

    for file_path in files:
        ext = file_path.suffix.lower()
        read_fn = readers[ext]

        try:
            text = read_fn(file_path)

            if not text.strip():
                agent_log.warning(f"'{file_path.name}' appears empty — skipping.")
                continue

            raw_documents.append((text, file_path.name))
            agent_log.step(f"Loaded '{file_path.name}' ({len(text):,} characters)")

        except Exception as e:
            agent_log.error(f"Could not read '{file_path.name}': {e}")
            continue

    if not raw_documents:
        agent_log.warning("All files were empty or unreadable.")
        return []

    # ------------------------------------------------------------------
    # Step 3: Split text into chunks
    #
    # RecursiveCharacterTextSplitter tries to split on:
    #   1. "\n\n" (paragraph break) — best
    #   2. "\n"   (line break)      — second
    #   3. " "    (word boundary)   — last resort
    # This keeps sentences and paragraphs intact as much as possible.
    # ------------------------------------------------------------------
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        separators=["\n\n", "\n", " ", ""],
    )

    all_chunks: List[Document] = []

    for raw_text, filename in raw_documents:
        text_chunks = splitter.split_text(raw_text)

        agent_log.step(
            f"'{filename}' → {len(text_chunks)} chunks "
            f"(size={chunk_size}, overlap={chunk_overlap})"
        )

        for idx, chunk_text in enumerate(text_chunks):
            doc = Document(
                page_content=chunk_text,
                metadata={
                    "source": filename,
                    "chunk_index": idx,
                    "total_chunks": len(text_chunks),
                    "char_count": len(chunk_text),
                }
            )
            all_chunks.append(doc)

    agent_log.done(
        f"Complete — {len(all_chunks)} total chunks from {len(raw_documents)} document(s)"
    )

    return all_chunks


# =============================================================================
# Self-test — run: python ingestion/document_loader.py
# =============================================================================

if __name__ == "__main__":
    from config import settings

    print("=" * 60)
    print("Document Loader — Self Test")
    print("=" * 60)

    chunks = load_documents(settings.DOCUMENTS_DIR)

    if not chunks:
        print("No chunks produced. Add a document to the documents/ folder.")
        sys.exit(1)

    print(f"\nTotal chunks produced: {len(chunks)}")
    print("\n--- First Chunk ---")
    print(f"Source   : {chunks[0].metadata['source']}")
    print(f"Chunk #  : {chunks[0].metadata['chunk_index']} of {chunks[0].metadata['total_chunks']}")
    print(f"Length   : {chunks[0].metadata['char_count']} characters")
    print(f"Content  :\n{chunks[0].page_content}")
    print("\n--- Last Chunk ---")
    print(f"Source   : {chunks[-1].metadata['source']}")
    print(f"Content  :\n{chunks[-1].page_content}")
    print("\n✅ Document loader working correctly!")