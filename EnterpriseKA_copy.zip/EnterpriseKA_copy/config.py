"""
config.py  --  Central configuration for the Enterprise Knowledge Agent.

WHY THIS FILE EXISTS
--------------------
Instead of scattering API keys, model names, and folder paths across many
files, we keep them in ONE place. Every other module imports `settings`
(for values) and `get_llm()` (to get the language model).

This gives us two big wins:
  1. Secrets (API keys) are loaded from a .env file, never hard-coded.
  2. Swapping the LLM is a one-line change in .env — all agents
     automatically use the new model via get_llm().
"""

import os
import ssl
from pathlib import Path
from dotenv import load_dotenv

# =============================================================================
# Corporate Network SSL Fix
# Must be at the top before any network-related imports
# =============================================================================
os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["REQUESTS_CA_BUNDLE"] = ""
os.environ["CURL_CA_BUNDLE"] = ""
ssl._create_default_https_context = ssl._create_unverified_context

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Patch httpx for corporate proxy (used by some Google libraries)
try:
    import httpx
    _orig = httpx.Client.__init__
    def _patched(self, *args, **kwargs):
        kwargs.setdefault("verify", False)
        _orig(self, *args, **kwargs)
    httpx.Client.__init__ = _patched

    _orig_async = httpx.AsyncClient.__init__
    def _patched_async(self, *args, **kwargs):
        kwargs.setdefault("verify", False)
        _orig_async(self, *args, **kwargs)
    httpx.AsyncClient.__init__ = _patched_async
except ImportError:
    pass
# =============================================================================

PROJECT_ROOT = Path(__file__).parent
load_dotenv(PROJECT_ROOT / ".env")


# =============================================================================
# Settings
# =============================================================================

class Settings:
    """
    Single container for all configuration values.
    Read from .env file — never hardcode secrets here.
    """

    # --- LLM Provider ---
    LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "gemini").lower()

    # --- Google Gemini ---
    GOOGLE_API_KEY: str = os.getenv("GOOGLE_API_KEY", "")
    GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

    # --- Anthropic Claude (optional) ---
    ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")
    CLAUDE_MODEL: str = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-6")

    # --- LLM Behaviour ---
    # Temperature 0.0 = focused, deterministic answers (best for RAG)
    LLM_TEMPERATURE: float = float(os.getenv("LLM_TEMPERATURE", "0.0"))

    # --- Folder Paths ---
    DOCUMENTS_DIR: Path = PROJECT_ROOT / os.getenv("DOCUMENTS_DIR", "documents")
    VECTOR_STORE_PATH: Path = PROJECT_ROOT / os.getenv("VECTOR_STORE_PATH", "vector_store")

    # --- Logging ---
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO").upper()

    # --- Embeddings ---
    # Using gemini-embedding-001 via REST API (no SDK needed)
    EMBEDDING_MODEL: str = "gemini-embedding-001"

    # --- RAG Settings ---
    CHUNK_SIZE: int = 512        # Max characters per chunk
    CHUNK_OVERLAP: int = 64      # Overlap between chunks to avoid cutting sentences
    TOP_K_RESULTS: int = 5       # How many chunks to retrieve per query

    # --- Agent Settings ---
    MAX_ITERATIONS: int = 10
    MIN_CONFIDENCE_THRESHOLD: float = 0.6


settings = Settings()


# =============================================================================
# REST-based Gemini LLM
# =============================================================================
# WHY NOT USE langchain_google_genai?
# That package uses 'protobuf' internally which crashes on Python 3.14 with:
#   "TypeError: Metaclasses with custom tp_new are not supported"
#
# This class bypasses ALL Google SDK packages and calls the Gemini REST API
# directly using the 'requests' library — pure HTTP, works on any Python version.
#
# It mimics LangChain's interface exactly:
#   llm.invoke("your prompt") → returns object with .content attribute
# So all agents work without any changes.
# =============================================================================

class GeminiRESTLLM:
    """
    Pure REST client for Gemini — no protobuf, no Google SDK.

    Mimics LangChain's ChatModel interface:
      response = llm.invoke("your prompt")
      print(response.content)  # the text reply

    Works on Python 3.14, Python 3.11, any version.
    """

    def __init__(
        self,
        api_key: str,
        model: str = "gemini-2.0-flash",
        temperature: float = 0.0
    ):
        self.api_key = api_key
        self.temperature = temperature

        # Strip 'models/' prefix if present — it's already in the URL path
        # e.g. 'models/gemini-2.0-flash' → 'gemini-2.0-flash'
        self.model = model.replace("models/", "")

        self.url = (
            f"https://generativelanguage.googleapis.com"
            f"/v1beta/models/{self.model}:generateContent"
        )

    class _Response:
        """
        Mimics LangChain's AIMessage object.
        Has a .content attribute so all agents work unchanged.
        """
        def __init__(self, text: str):
            self.content = text

        def __repr__(self):
            return f"GeminiResponse(content={self.content[:80]}...)"

    def invoke(self, prompt: str) -> "_Response":
        """
        Send a prompt to Gemini with automatic retry AND automatic
        failover to a backup API key if the primary is rate limited.
        """
        import requests
        import time

        keys_to_try = [("primary", self.api_key)]
        backup_key = os.getenv("GOOGLE_API_KEY_BACKUP", "")
        if backup_key:
            keys_to_try.append(("backup", backup_key))

        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": self.temperature},
        }

        last_error = None

        for key_label, current_key in keys_to_try:
            max_retries = 2
            for attempt in range(max_retries):
                response = requests.post(
                    self.url,
                    params={"key": current_key},
                    json=payload,
                    verify=False,
                    timeout=60,
                )

                if response.status_code == 200:
                    data = response.json()
                    text = (
                        data.get("candidates", [{}])[0]
                        .get("content", {})
                        .get("parts", [{}])[0]
                        .get("text", "")
                    )
                    if not text:
                        raise RuntimeError(f"Empty response: {str(data)[:300]}")
                    return self._Response(text)

                elif response.status_code == 429:
                    last_error = response.text[:300]
                    if attempt < max_retries - 1:
                        wait = (attempt + 1) * 10
                        print(f"  [{key_label} key] Rate limit. Waiting {wait}s...")
                        time.sleep(wait)
                    else:
                        print(f"  [{key_label} key] Exhausted. Trying next key...")
                    continue

                else:
                    raise RuntimeError(
                        f"Gemini API error {response.status_code}: {response.text[:300]}"
                    )

        raise RuntimeError(
            f"All API keys rate limited. Last error: {last_error}. "
            "Check https://aistudio.google.com/app/usage"
        )


# =============================================================================
# get_llm() — The single function all agents use to get the LLM
# =============================================================================

def get_llm() -> GeminiRESTLLM:
    """
    Return a ready-to-use LLM instance.

    All agents call this. They never import a specific model class directly.
    This is the 'provider abstraction' — swap the LLM in .env and
    every agent automatically uses the new model.

    Returns:
        GeminiRESTLLM instance (or Claude if configured)

    Raises:
        ValueError: if the required API key is missing
    """
    provider = settings.LLM_PROVIDER

    if provider in ("gemini", "google"):
        if not settings.GOOGLE_API_KEY or settings.GOOGLE_API_KEY == "your_gemini_key_here":
            raise ValueError(
                "GOOGLE_API_KEY is missing or still placeholder.\n"
                "Get a free key at https://aistudio.google.com/app/apikey"
            )
        return GeminiRESTLLM(
            api_key=settings.GOOGLE_API_KEY,
            model=settings.GEMINI_MODEL,
            temperature=settings.LLM_TEMPERATURE,
        )

    if provider == "claude":
        if not settings.ANTHROPIC_API_KEY:
            raise ValueError(
                "ANTHROPIC_API_KEY is missing. "
                "Or set LLM_PROVIDER=gemini to use Google instead."
            )
        from langchain_anthropic import ChatAnthropic
        return ChatAnthropic(
            model=settings.CLAUDE_MODEL,
            anthropic_api_key=settings.ANTHROPIC_API_KEY,
            temperature=settings.LLM_TEMPERATURE,
        )

    raise ValueError(
        f"Unknown LLM_PROVIDER '{provider}'. Use 'gemini' or 'claude'."
    )

def validate_config() -> bool:
    """
    Check that essential configuration values are present.
    Called at startup so the user gets a clear error message early.

    Returns:
        True if config is valid, False if something critical is missing
    """
    errors = []

    if not settings.GOOGLE_API_KEY or settings.GOOGLE_API_KEY == "your_gemini_key_here":
        errors.append(
            "GOOGLE_API_KEY is not set. "
            "Add it to your .env file."
        )

    # Auto-create directories if they don't exist
    settings.DOCUMENTS_DIR.mkdir(parents=True, exist_ok=True)
    settings.VECTOR_STORE_PATH.mkdir(parents=True, exist_ok=True)

    if errors:
        for error in errors:
            print(f"[CONFIG ERROR] {error}")
        return False

    return True